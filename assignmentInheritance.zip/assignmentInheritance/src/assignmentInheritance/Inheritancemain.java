package assignmentInheritance;

import java.util.Scanner;

class BankAccount1 {
    private String accountNumber, accountHolder;
    private static double balance;
 // constructor to initialize the account number, account holder, and balance
    public BankAccount1(String accountNumber, String accountHolder, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

//    setter and getter functions
    public String getAc_no() {
        return accountNumber;
    }

    public void setAc_no(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getAc_ho() {
        return accountHolder;
    }

    public void setAc_ho(String accountHolder) {
        this.accountHolder = accountHolder;
    }

    public double getAc_bal() {
        return balance;
    }

    public void setAc_bal(double balance) {
        this.balance = balance;
    }

    
//    deposit method
    public static double deposit(double amount) {
        balance = balance + amount;
        return balance;
    }

// method to print accont details
    public void displayAccountDetails() {
        System.out.println("Account Holder: " + accountHolder);
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Balance: " + balance);
    }
}


// subclass SavingsAccount
class SavingsAccount extends BankAccount1 {
    private double interestRate;
// constructor to initialize variables
    SavingsAccount(String accountNumber, String accountHolder, double balance, double interestRate) {
        super(accountNumber, accountHolder, balance);
        this.interestRate = interestRate;
    }
// method to print Account Details
    public void displayAccountDetails() {
        super.displayAccountDetails();
        System.out.println("Interest Rate: " + interestRate);
    }

//     method applyInterest() that calculates and adds interest to the balance based on the interestRate
    public void applyInterest() {
        double total = interestRate * getAc_bal();
        deposit(total);
        System.out.println("Interest applied: " + total);
    }
}
// subclass CheckingAccount
class CheckingAccount extends BankAccount1 {
    private double overdraftLimit;
//    constructor
    CheckingAccount(String accountNumber, String accountHolder, double balance, double overdraftLimit) {
        super(accountNumber, accountHolder, balance);
        this.overdraftLimit = overdraftLimit;
    }
// withdraw method
    public double withdraw(double amount) {
        if (getAc_bal() - amount >= overdraftLimit) {
            setAc_bal(getAc_bal() - amount);
        } else {
            System.out.println("exceeded overdraft limit,not able to withdraw");
        }
        return getAc_bal();
    }

//  Override the withdraw(double amount) method to allow overdrawing up to the overdraft limit
    public void displayAccountDetails() {
        super.displayAccountDetails();
        System.out.println("overdraft limit: " + overdraftLimit);
    }
}

public class Inheritancemain {
    public static void main(String args[]) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter account holder name");
    	String ah=sc.nextLine();
    	System.out.println("enter account number");
    	String an=sc.nextLine();
    	double b=10000;
    	SavingsAccount obj1 = new SavingsAccount(an,ah,b,6.5);
        obj1.displayAccountDetails();
    	int c;
    	System.out.println("enter your choice withdraw(2) deposit(1)");
    	c=sc.nextInt();
    	System.out.println("enter the amount you want to deposit or withdraw");
    	double amt=sc.nextInt();
    	        switch (c) {
    	            case 1:
    	            	obj1.applyInterest();
    	                double bal=BankAccount1.deposit(amt);
    	                obj1.displayAccountDetails();
    	                break;
    	            case 2:
    	            	System.out.println("enter overdraft limit");
    	            	double o=sc.nextInt();
    	                CheckingAccount obj2 = new CheckingAccount(an,ah,b,o);
    	                obj2.withdraw(amt);
    	                obj2.displayAccountDetails();	
    	                break;
    	        }
     
    }
}


//Assignment Tasks:
//Create a Base Class BankAccount
//Attributes: accountNumber (String), accountHolder (String), balance (double).
//Encapsulate these attributes with private access modifiers and provide public getter and setter methods.
//Include a constructor to initialize the account number, account holder, and balance.
//Implement methods for deposit(double amount), which allows adding money to the account, and withdraw(double amount), which ensures that the balance cannot go negative.
//Include a method displayAccountDetails() to print the account details, including the account type.
//Create a Derived Class SavingsAccount from BankAccount
//Add an attribute interestRate (double).
//Include a constructor that takes parameters for initialization, including the interestRate, and calls the superclass constructor for other attributes.
//Override the displayAccountDetails() method to include displaying the interestRate.
//Add a method applyInterest() that calculates and adds interest to the balance based on the interestRate.
//Create a Derived Class CheckingAccount from BankAccount
//Introduce an attribute overdraftLimit (double).
//Include a constructor that initializes the new attribute along with those of the superclass.
//Override the withdraw(double amount) method to allow overdrawing up to the overdraft limit.
//Override the displayAccountDetails() method to include the overdraft limit.
//Demonstrate Functionality in a Main Class
//Create instances of SavingsAccount and CheckingAccount.
//Demonstrate making deposits, withdrawals, applying interest, and showing the flexibility of the overdraft feature.
//Print the account details after each operation to show the changes.
