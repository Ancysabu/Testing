/**
 * 
 */
/**
 * 
 */
module assignmentInheritance {
}