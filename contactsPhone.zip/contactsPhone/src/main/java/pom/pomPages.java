package pom;

import java.util.Iterator;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;



public class pomPages {
      public static AndroidDriver driver;
      
      
      public  pomPages(AndroidDriver driver) {
    	  this.driver = driver;
    	  PageFactory.initElements(new AppiumFieldDecorator(driver), this);
      }
      
      @AndroidFindBy(id="android:id/button2")
      WebElement skipElement;
      
      @AndroidFindBy(id="com.android.permissioncontroller:id/permission_allow_button")
      WebElement allowButton;
      
      @AndroidFindBy(accessibility = "Create contact")
      WebElement plusSign;
      
      @AndroidFindBy(className ="android.widget.EditText")
      List<WebElement> input;
      
      @AndroidFindBy(id="com.google.android.contacts:id/toolbar_button")
      WebElement save;
      
      @AndroidFindBy(id="com.google.android.contacts:id/floating_action_button")
      WebElement editElement;
      
      
      @AndroidFindBy(xpath="//android.widget.ImageView[@content-desc=\"More options\"]")
      WebElement moreOptions;
      
      @AndroidFindBy(xpath ="/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.RelativeLayout/android.widget.TextView")
      WebElement deleteOption;
      
      @AndroidFindBy(id="android:id/button1")
      WebElement deletebtn;
      
      @AndroidFindBy(id="com.google.android.contacts:id/large_title")
      WebElement addContacts;
      
      @AndroidFindBy(id="com.google.android.contacts:id/attribution_header")
      WebElement delete;
      
      public void clickSkip() {
    	  skipElement.click();
      }
      
      public void clickAllowBtn() {
    	  allowButton.click();
      }
      
      public void clickPlusSign() {
    	  plusSign.click();
      }
      
      public void enterFirstName(String name){
    	 input.get(0);
    	 input.get(0).sendKeys(name);
      }
      

      public void enterLastName(){
    	 input.get(1).sendKeys("Kumari");
      }
      

      public void enterCompany(){
    	 input.get(2).sendKeys("UST");
      }
      

      public void enterPhone(){
    	 input.get(3).sendKeys("1234567890");
      }
      

      public void enterEmail(){
    	 input.get(4).sendKeys("Aishkumari@gmail.com");
      }
      
      public void clickSave() {
    	  save.click();
      }
      
      public void clickEdit() {
    	  editElement.click();
      }
      
      public void clickMoreOptions() {
    	  moreOptions.click();
      }
      
      public void clickDeleteOption() {
    	  deleteOption.click();
      }
      public void clickDeleteBtn() {
    	  deletebtn.click();
      }
      public String validateAddToContacts() {
    	 return addContacts.getText();
      }
      public int validateDelete() {
    	  String[] value = delete.getText().split(" ");
    	  return Integer.parseInt(value[2]);
    	  
      }
}  
      
//      for(WebElement ele : input)
//      {
//    	  System.out.println(ele.getText());
// 
      
    
