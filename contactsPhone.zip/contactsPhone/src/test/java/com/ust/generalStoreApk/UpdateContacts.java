package com.ust.generalStoreApk;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import pom.pomPages;

public class UpdateContacts extends AddContacts{
@Test
	public void UpdateContactsTest() {
		pomPages pom = new pomPages(driver);
		pom.clickEdit();
		pom.enterFirstName("Aishuu");
		pom.clickSave();
		assertEquals(pom.validateAddToContacts().contains("Aishuu"),true);
		pom.clickMoreOptions();
		pom.clickDeleteOption();
		pom.clickDeleteBtn();
		assertEquals(contactsbeforeDelete-pom.validateDelete(),0);
	}
}
