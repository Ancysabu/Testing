package com.ust.generalStoreApk;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import utils.AppiumServerManager;


public class BaseTest {
	public AndroidDriver driver;

	@BeforeTest
	public void setup() throws MalformedURLException {
	
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Ancy_phone");
		options.setAppPackage("com.google.android.contacts");
    	options.setAppActivity("com.google.android.apps.contacts.activities.PeopleActivity");
		options.setPlatformName("Android");
		AppiumServerManager.startServer();
		driver = new AndroidDriver(new URL("http://127.0.0.1:" + AppiumServerManager.getport() ), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("App opened");
	}
	
}
