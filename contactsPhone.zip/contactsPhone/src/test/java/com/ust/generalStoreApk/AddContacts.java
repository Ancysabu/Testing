package com.ust.generalStoreApk;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.util.HashMap;

import org.testng.annotations.Test;

import pom.pomPages;
import utils.DataProviders;


public class AddContacts extends BaseTest {
	
	 static int contactsbeforeDelete;
	 
     @Test(dataProviderClass = DataProviders.class,dataProvider = "Jsondata")
     public void AddToContactsTest(HashMap<String,String> map) {
    	 pomPages pom = new pomPages(driver);
    	 pom.clickSkip();
    	 pom.clickAllowBtn();
    	 contactsbeforeDelete = pom.validateDelete();
    	 pom.clickPlusSign();
    	 pom.enterFirstName(map.get("First_name"));
    	 pom.enterLastName();
    	 pom.enterCompany();
    	 pom.enterPhone();
    	 pom.enterEmail();
    	 pom.clickSave();
    	 assertEquals(pom.validateAddToContacts().contains("Roshan"),true);
      
     }
//     
//     @Test(dataProviderClass = DataProviders.class,dataProvider = "Jsondata")
// 	public void testenterData(HashMap<String,String> map) throws IOException {
// 		System.out.println(map.get("First_name"));
// 	}
}
