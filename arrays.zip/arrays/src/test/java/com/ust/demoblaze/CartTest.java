package com.ust.demoblaze;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import pomdemoblaze.CartPage;
import pomdemoblaze.HomeIKEAPage;
import pomdemoblaze.HomePage;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

//@Listeners(utilities.ExtentReportsListener.class)
public class CartTest implements ITestListener{
public WebDriver driver;
//ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	
	@BeforeClass(groups="cart")
	public void browserSetup() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		driver = rf.invokeBrowser();
	}
	
	@BeforeMethod(groups="cart")
	public void before() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
	}
	@DataProvider(name="valid")
	public String[][] getData() throws IOException{
		String path = System.getProperty("user.dir")+"\\TestData\\fillup data.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path,sheetName);
	}
	@Test
	
	public void testCart() throws InterruptedException  {
	
//		HomeIKEAPage home = new HomeIKEAPage(driver);
//		home.clickCookiesOk();
//		home.clickHej();
//		Thread.sleep(1000);
//		home.clicklogin();
//		home.enterfirstname();
//		home.entersurname();
//		home.enterbirthdate();
//		home.selectgender();
//		home.enterpostcode();
//		home.selectlocn();
//		home.enterphoneno();
//		home.enteremail();
//		home.enterpassword();
////		home.unclickcheckbox();
////		home.clickcheckbox();
//		home.phoneverify();
		
//		driver.findElement(By.linkText("Hello, Log in")).click();
//		driver.findElement(By.linkText("My Account")).click();
//		apollo driver.findElement(By.xpath("//input[@name='mobileNumber']")).sendKeys("9645352349");
//		driver.findElement(By.cssSelector("input#CustomerPassword")).sendKeys("Aishu@2001");
//		driver.findElement(By.xpath("(//input[@class='btn btn--solid-color '])[1]")).click();
//		
//		apollo driver.findElement(By.xpath("//button[@title='Login']")).click();
//		apollo Thread.sleep(30000);
//		apollo driver.findElement(By.xpath("//button[@title='Login']")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.linkText("Apollo Products")).click();
//		Actions a = new Actions(driver);
//		a.moveToElement(driver.findElement(By.linkText("Apollo Products"))).build().perform();
//		driver.findElement(By.linkText("Vitamins")).click();
//		Thread.sleep(2000);
//		driver.findElement(By.xpath("//div[@class='_accordionPanel_28w9f_15  CategoryFilterWeb_accordionHeader__R6CpE ']/h2")).click();
//		Thread.sleep(1000);
//		driver.findElement(By.xpath("(//input[@type='checkbox'])[1]")).click();
//		Thread.sleep(2000);
//	    assertEquals(true,driver.findElement(By.xpath("(//div[@class='Ov']/h2)[1]")).getText().contains("Apollo Pharmacy"));
	
//		driver.findElement(By.xpath("(//button[@class='sc-b7e936f3-0 sc-8d6a8564-0 dOqDEV dDFrfH'])[2]")).click();
//		driver.findElement(By.xpath("//input[@class='MuiInputBase-input MuiOutlinedInput-input css-1x5jdmq']")).sendKeys("9645352349");
//		driver.findElement(By.xpath("//button[@class='sc-b7e936f3-0 sc-d33efae0-0 dOqDEV bVkQco sc-2ba17253-9 fnsHfX']")).click();
//		
//		driver.findElement(By.xpath("//input[@class='search-input']")).sendKeys("Dolo");
//		driver.findElement(By.xpath("//button[@class='search-primary-btn']")).click();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("(//button[@class='sc-b7e936f3-0 sc-d33efae0-0 dOqDEV bVkQco sc-95f5ff3a-1 gLhIHs'])[1]")).click();
//		driver.findElement(By.xpath("//button[@class='sc-b7e936f3-0 sc-d33efae0-0 dOqDEV bVkQco sc-7e8b0b9c-17 bNREzx']")).click();
//		
		
		driver.findElement(By.id("login-email")).sendKeys("aisuanilkumar@gmail.com");
		driver.findElement(By.id("login-password")).sendKeys("AishQwerty@123");
		Thread.sleep(20000);
		driver.findElement(By.xpath("//div[@class='brz-popup2__close']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//button[@class='button btn login-page-bttn std-btn d-block m-auto'])[1]")).click();
		
		
		
		
		
		
		
		
		
		
		
		
		
//		HomePage home= new HomePage(driver);
//		Thread.sleep(10000);
//		home.clickProduct();
//		CartPage cart= new CartPage(driver);
//		Thread.sleep(10000);
//		cart.clickAddToCart();
//		Thread.sleep(10000);
//		cart.clickCart();
//		assertEquals("https://www.demoblaze.com/cart.html",driver.getCurrentUrl());
//		Thread.sleep(1000);
////		cart.clickDelete();
////		Thread.sleep(1000);
////		assertEquals(cart.validateDelete(),0);
//		cart.clickPlaceOrder();
//		Thread.sleep(1000);
//		cart.enterName(name);
//		cart.enterCountry(country);
//		cart.enterCity(city);
//		cart.enterCreditCard(creditcard);
//		cart.enterMonth(month);
//		cart.enterYear(year);
//		
//		cart.clickPurchase();
//		Thread.sleep(1000);
//		cart.clickOK();
	
	}
//	@AfterMethod
//	public void captureScreenshotOfFail(ITestResult result) {
//		if(result.getStatus() == ITestResult.FAILURE) {
//			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//			try {
//				Date d1 = new Date();
//				FileUtils.copyFile(screenshot, new File("ss/"+ d1.getTime()+ "ss.jpg"));
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}
	
	
}
