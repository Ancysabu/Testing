package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ExcelHandling {
	public static String[][] getExcelData(String path, String sheetName) throws IOException{
		FileInputStream fis = new FileInputStream(new File(path));
		XSSFWorkbook workbook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workbook.getSheet(sheetName);
		int rowCount = sheet.getPhysicalNumberOfRows();
		int colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		String [][] sheetarray = new String [rowCount][colCount];
		DataFormatter dt = new DataFormatter();
		for(int i=0;i<rowCount;i++) {
			for(int j=0;j<colCount;j++) {
				sheetarray[i][j]= dt.formatCellValue(sheet.getRow(i).getCell(j));
			}
		}
		return sheetarray;
	}
}
