package pomdemoblaze;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomeIKEAPage {
public WebDriver driver;
	
	public HomeIKEAPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="(//button[@id='onetrust-accept-btn-handler'])[1]")
	WebElement cookiesOK;
	
	@FindBy(xpath="(//span[@class='hnf-btn__inner'])[5]")
	WebElement hej;
	
	@FindBy(xpath="(//span[@class='btn__inner'])[1]")
	WebElement login;
	
	@FindBy(css="input#username")
	WebElement firstname;
	
	@FindBy(css="input#family-signup-form-lastName")
	WebElement surname;
	
	@FindBy(css="input#family-signup-form-birthDate")
	WebElement birthdate;
	
	@FindBy(css="select#family-signup-form-genderCode")
	WebElement gender;
	
	@FindBy(css="input#family-signup-form-zipCode")
	WebElement postcode;
	
	@FindBy(css="select#family-signup-form-preferredStore")
	WebElement locn;
	
	@FindBy(css="input#family-signup-form-phoneNumber")
	WebElement phoneno;
	
	@FindBy(css="input#family-signup-form-email")
	WebElement email;
	
	@FindBy(css="input#password")
	WebElement password;
	
    @FindBy(css="input#family-signup-form-contact-method-communications")
    WebElement checkboxunclick;
    
	@FindBy(css="input#family-signup-form-double-consent")
	WebElement checkboxclick;
	
	@FindBy(xpath="(//span[@class='btn__label'])[2]")
	WebElement phnverify;
	
	public void clickCookiesOk() {
		cookiesOK.click();
	}
	public void clickHej() {
		hej.click();
	}
	public void clicklogin() {
		login.click();
	}
	public void enterfirstname() {
		firstname.sendKeys("aisuanilkumar@gmail.com");
	}
	public void entersurname() {
		surname.sendKeys("A");
	}
	public void enterbirthdate() {
		birthdate.sendKeys("15-03-2001");
	}
	public void selectgender() {
		gender.click();
		Select s= new Select(gender);
		s.selectByValue("FEMALE");
	}
	public void enterpostcode() {
	   postcode.sendKeys("695101");
	}
	public void selectlocn() {
		locn.click();
		Select s= new Select(locn);
		s.selectByValue("578");
	}
	public void enterphoneno() {
		   phoneno.sendKeys("9567324528");
		}
	public void enteremail() {
		   email.sendKeys("aisuanilkumar@gmail.com");
		}
	public void enterpassword() {
		   password.sendKeys("Aishu@2001");
		}
	public void unclickcheckbox() {
		checkboxunclick.click();
	}
	public void clickcheckbox() {
		checkboxclick.click();
	}
	public void phoneverify() {
		phnverify.click();
	}
	
}