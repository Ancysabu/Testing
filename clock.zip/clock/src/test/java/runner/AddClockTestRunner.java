package runner;

import org.testng.annotations.Listeners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
		glue="step_definitions",
		features="src\\test\\resources\\features\\AddClock.feature",plugin = {
				"pretty", "html:reportes/1.html",
				 }
		)
@Listeners(utilities.ExtentReportsListener.class)
public class AddClockTestRunner extends AbstractTestNGCucumberTests{
}
