package clockTest;

import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.appiumUtilities.AppiumServerManager;
import com.ust.pom.ClockPage;


import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

@Listeners(utilities.ExtentReportsListener.class)
public class clockAppTest {

	public AndroidDriver driver;

	@BeforeMethod
	public void setup() throws MalformedURLException {
		String port = AppiumServerManager.startServer();
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Ancy_phone");
		options.setAppPackage("com.google.android.deskclock");
		options.setAppActivity("com.android.deskclock.DeskClock");
		options.setPlatformName("Android");
		driver = new AndroidDriver(new URL("http://127.0.0.1:"+ port), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	
	@Test(priority=1)
	public void setAlarm() {
		ClockPage clockPage = new ClockPage(driver) ;
		clockPage.clickAlarm();
		clockPage.clickAddAlarm();
		clockPage.clickTextInput();
		clockPage.enterHour("6");
		clockPage.enterMinute("30");
		clockPage.clickOk();
		assertEquals(clockPage.validateSetAlarm(), "6:30 PM");
		assertEquals(clockPage.validateAlarm(), "true");
		
		System.out.println("Alarm Opened");
}
	@Test(priority=2)
	public void deleteAlarm() {
		ClockPage clockPage = new ClockPage(driver) ;
		clockPage.clickAlarm();
		clockPage.clickElapsedBtn();
		clockPage.clickDeleteBtn();
		assertEquals(clockPage.validateDeleteAlarm(), 1);
	}
}