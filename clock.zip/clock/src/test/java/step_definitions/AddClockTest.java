package step_definitions;

import static org.testng.Assert.assertEquals;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;

import com.ust.pom.ClockPage;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


/** Test cases for testing the search feature of Contacts App
 * @author Ancy **/
@Listeners(utilities.ExtentReportsListener.class)
public class AddClockTest implements ITestListener {
	private final AndroidDriver driver = Hooks.driver;
	@Given("User opens the Clock app")
	public void user_opens_the_clock_app() {
		ClockPage clockPage = new ClockPage(driver);
		clockPage.clickClock();
		System.out.println("Clock app opened");
	}
	@Given("User clicks on add button")
	public void user_clicks_on_add_button() {
		ClockPage clockPage = new ClockPage(driver);
		clockPage.clickAddCity();
	}
	@When("User enters {string} on the search bar")
	public void user_enters_on_the_search_bar(String string) {
		ClockPage clockPage = new ClockPage(driver);
		clockPage.enterSearchvalue(string);
		
	}
	@When("User selects the city")
	public void user_selects_the_city() {
		ClockPage clockPage = new ClockPage(driver);
		clockPage.clickSearchResult();
	}
	@Then("Clock of {string} is added")
	public void clock_of_is_added(String string) {
		ClockPage clockPage = new ClockPage(driver);
		assertEquals(clockPage.validateCityClock(), string);
	}
}




