package com.ust.pom;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidBy;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class ClockPage {
public AndroidDriver driver;
	
	public ClockPage(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(accessibility = "Alarm")
	WebElement alarmBtn;
	
	@AndroidFindBy(accessibility = "Add alarm")
	WebElement addAlarm;
	
	@AndroidFindBy(xpath="//android.widget.Button[@content-desc=\"Switch to text input mode for the time input.\"]")
	WebElement textInput;
	
	@AndroidFindBy(className = "android.widget.CompoundButton")
	List<WebElement> textboxes;
	
	@AndroidFindBy(className = "android.widget.EditText")
	List<WebElement> editTexts;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/material_timepicker_ok_button")
	WebElement okBtn;
	
	@AndroidFindBy(accessibility = "6:30 PM")
	WebElement setAlarm;
	
	@AndroidFindBy(xpath  = "(//androidx.cardview.widget.CardView[@content-desc=\" Alarm\"])[2]/android.view.ViewGroup/android.widget.Switch")
	WebElement enablebtN;
	
	@AndroidFindBy(xpath="(//android.widget.ImageButton[@content-desc=\"Expand alarm\"])[2]")
	WebElement elapsedBtn;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/delete")
	WebElement deleteBtn;
	
	@AndroidFindBy(className = "android.widget.Switch")
	List<WebElement> enabledswitch; 
	
	@AndroidFindBy(accessibility = "Add city")
	WebElement addCity;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/open_search_view_edit_text")
	WebElement searchbar;
	
	@AndroidFindBy(id="com.google.android.deskclock:id/city_name")
	WebElement searchResult;
	
	@AndroidFindBy(accessibility = "Clock")
	WebElement clock;
	
	public void clickAlarm() {
		alarmBtn.click();
	}
	
	public void clickAddAlarm() {
		addAlarm.click();
	}
    
	public void clickTextInput() {
		textInput.click();
	}
	
	public void enterHour(String hour) {
		textboxes.get(0).click();
		editTexts.get(0).sendKeys(hour);
	}
	
	public void enterMinute(String minute) {
		textboxes.get(0).click();
		editTexts.get(0).sendKeys(minute);
	}
	
	public void clickOk() {
		okBtn.click();
	}
	
	public String validateSetAlarm() {
		return setAlarm.getText();
	}
	
	public String validateAlarm() {
		return enablebtN.getAttribute("checked");
	}
	
	public void clickElapsedBtn() {
		elapsedBtn.click();
	}
	
	public void clickDeleteBtn() {
		deleteBtn.click();
	}
	
	public Integer validateDeleteAlarm() {
		return enabledswitch.size();
	}
	
	public void clickAddCity() {
		addCity.click();
	}
	
	public void enterSearchvalue(String city) {
		searchbar.sendKeys(city);
	}
	public void clickSearchResult() {
		searchResult.click();
	}
	public String validateCityClock() {
		return searchResult.getText();
	}
	public void clickClock() {
		clock.click();
	}
}