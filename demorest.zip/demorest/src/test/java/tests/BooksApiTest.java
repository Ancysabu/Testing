package tests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import endpoints.SlackTeamEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.SlactTeamModel;

public class BooksApiTest {
	
//	public SlactTeamModel team;
	
//	@BeforeClass
//	public void setup() {
//		team=new SlactTeamModel(3);
//	}
//	
//	Test method for get single book
	@Test(priority=1)
	public void getSingleBook() {
		RestAssured.useRelaxedHTTPSValidation();
		SlactTeamModel team=new SlactTeamModel(3);
		Response response=SlackTeamEndpoints.getSingleBook(team.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
 
	}
	
//	Test method for get books list
	@Test(priority=2)
	public void getAllBooks() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=SlackTeamEndpoints.getBooklist();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method for post a book
	@Test(priority=3)
	public void postBook() {
		RestAssured.useRelaxedHTTPSValidation();
		SlactTeamModel team1=new SlactTeamModel("abcd","xyz","abc@gmail.com","ardtjfkg");
		Response response=SlackTeamEndpoints.createBook(team1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
}