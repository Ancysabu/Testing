package endpoints;


import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.SlactTeamModel;
public class SlackTeamEndpoints {
	
//	Response method for get books list
	public static Response getBooklist() {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(routes.baseUri)
				.basePath(routes.get_list)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
//	Response method for get single book
	public static Response getSingleBook(int id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(routes.baseUri)
				.basePath(routes.get_single)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
//	Response method for create new book
	public static Response createBook(SlactTeamModel payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(routes.baseUri)
				.basePath(routes.post)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}
//		// post a book
//			public static Response createBook(BookModels payload) {
//				Response response = RestAssured.given()
//						.headers(
//								
//								"Content-Type",
//								ContentType.JSON,
//								"Accept",
//								ContentType.JSON)
//						.baseUri(BooksRoutes.baseUri)
//						.basePath(BooksRoutes.post_book)
//						.contentType("application/json")
//						.accept(ContentType.JSON)
//						.body(payload)
//						.when()
//						.post();
//				return response;	
//			}
//
////			update a book
//			
//			public static Response updateBook(long id, BookModels payload) {
//				
//				Response response = RestAssured.given()
//						.headers(
//								
//								"Content-Type",
//								ContentType.JSON,
//								"Accept",
//								ContentType.JSON)
//						.baseUri(BooksRoutes.baseUri)
//						.basePath(BooksRoutes.put)
//						.pathParam("id", id)
//						.contentType("application/json")
//						.accept(ContentType.JSON)
//						.body(payload)
//						.when()
//						.put();
//				return response;	
//			}
//			
////			delete a book
//			
//			public static Response deleteBook(long id) {
//				Response response = RestAssured.given()
//						.headers(
//								
//								"Content-Type",
//								ContentType.JSON,
//								"Accept",
//								ContentType.JSON)
//						.baseUri(BooksRoutes.baseUri)
//						.basePath(BooksRoutes.delete)
//						.pathParam("id", id)
//						.contentType("application/json")
//						.accept(ContentType.JSON)
//						.when()
//						.delete();
//				return response;	
//			}
//				
		}

