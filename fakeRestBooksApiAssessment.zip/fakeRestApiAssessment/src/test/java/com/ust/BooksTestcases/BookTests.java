package com.ust.BooksTestcases;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;
import java.io.File;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import com.ust.fakeRest.endpoints.BooksEndpoints;
import com.ust.fakeRest.endpoints.BooksRoutes;
import com.ust.fakeRest.payloads.BookModels;
import io.restassured.RestAssured;
import io.restassured.response.Response;


@Listeners(com.ust.fakeRest.utilities.ExtentReportsListener.class)
public class BookTests{

	public BookModels bookPayload;
	
	@BeforeClass
	public void setup() {
		bookPayload=new BookModels(2,"Book 2", "Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\n", 200,"Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\n","2024-04-30T06:20:56.6305035+00:00");
	}
	
//	Test method to get single book
	
	@Test
	public void getSingleBook() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BooksEndpoints.getSingleBook(this.bookPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method to get all book
	
	@Test
	public void getAllBooks() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BooksEndpoints.getlistOfBooks(this.bookPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method to delete a book
	
	@Test
	public void deleteBook() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BooksEndpoints.deleteBook(this.bookPayload.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method to post a book
	
	@Test
	public void postBook() {
		BookModels bookPayload1=new BookModels();
		bookPayload1=new BookModels(100,"wings of fire","Lorem lorem lorem. Lorem lorem lorem.",300,"Lorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\nLorem lorem lorem. Lorem lorem lorem. Lorem lorem lorem.\\nLorem lorem lorem. Lorem lorem lorem.","2024-05-02");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BooksEndpoints.createBook(bookPayload1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method to update a book
	
	@Test
	public void putBook() {
		BookModels bookPayload2=new BookModels();
		bookPayload2=new BookModels(2,"Book 2", "Lorem lorem lorem....", 200,"desc Lorem lorem lorem....","2024-04-30");
		RestAssured.useRelaxedHTTPSValidation();
		Response response = BooksEndpoints.updateBook(2, bookPayload2);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method for schema validation
	
	@Test
    public void schemaValidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	    RestAssured.given()
	    .baseUri(BooksRoutes.for_schema_validation)
	        .when()
	        .get()
	        .then()
	        .assertThat()
	        .body(matchesJsonSchema(new File("C:\\Users\\268847\\eclipse-workspaceAPI\\fakeRestApiAssessment\\src\\test\\resources\\payload\\bookPayload.json")));
	}
}

