package com.ust.fakeRest.endpoints;

import com.ust.fakeRest.payloads.BookModels;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class BooksEndpoints {
// get the list of all books
	public static Response getlistOfBooks(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(BooksRoutes.baseUri)
				.basePath(BooksRoutes.get_all_books)
				.queryParam("page", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
// get single book
	public static Response getSingleBook(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(BooksRoutes.baseUri)
				.basePath(BooksRoutes.get_single_book)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
		
// post a book
	public static Response createBook(BookModels payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(BooksRoutes.baseUri)
				.basePath(BooksRoutes.post_book)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}

//	update a book
	
	public static Response updateBook(long id, BookModels payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(BooksRoutes.baseUri)
				.basePath(BooksRoutes.put)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
//	delete a book
	
	public static Response deleteBook(long id) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(BooksRoutes.baseUri)
				.basePath(BooksRoutes.delete)
				.pathParam("id", id)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.delete();
		return response;	
	}
		
}
