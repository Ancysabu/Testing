package com.ust.fakeRest.endpoints;

public class BooksRoutes {
	
	public static String baseUri="https://fakerestapi.azurewebsites.net";
	public static String get_all_books="/api/v1/Books";
	public static String get_single_book="/api/v1/Books/{id}";
	public static String post_book="/api/v1/Books";
	public static String put="/api/v1/Books/{id}";
	public static String delete="/api/v1/Books/{id}";
	public static String for_schema_validation="https://fakerestapi.azurewebsites.net/api/v1/Books/1";
	
}
