package com.ust.SauceDemo;

import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Pom.CartPage;
import Pom.LoginPage;
import Pom.ProductsPage;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class SauceDemoTest implements ITestListener {
    public WebDriver driver;
    ExtentReportsListener extentReportsListener = new ExtentReportsListener();
    
    @BeforeClass(groups="cart")
    public void beforeClass() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	driver=fn.invokeBrowser();
    			
    }
    
    @BeforeMethod(groups="cart")
    public void before() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	fn.openWebsite();
    }
    
    @DataProvider(name="invaliddata")
    public String[][] getData() throws IOException{
	String path = System.getProperty("user.dir") + "\\Testdata\\Book1.xlsx";
	String sheetName1="Sheet1";
	
	return ExcelHandling.getExcelData(path,sheetName1);
}
   @DataProvider(name="validdata")
    public String[][] getdData() throws IOException{
	String path = System.getProperty("user.dir") + "\\Testdata\\Book1.xlsx";
	String sheetName2="Sheet2";
	return ExcelHandling.getExcelData(path,sheetName2);
}

    @Test(dataProvider="invaliddata")
    
    public void testInvalidLogin(String username, String password) {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLogin();
  	    assertEquals(login.invaliddata(),"Epic sadface: Username and password do not match any user in this service");
  	    assertEquals("Swag Labs",driver.getTitle());
    }
    
    @Test(dataProvider="validdata")
    
    public void testValidLogin(String username,String password) {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLogin();
    	assertEquals("https://www.saucedemo.com/inventory.html",driver.getCurrentUrl());
 	    assertEquals("Swag Labs",driver.getTitle());
    }
    @Test
    public void testNullLogin() {
    	LoginPage login= new LoginPage(driver);
    	login.clickLogin();
    	assertEquals(login.invaliddata(),"Epic sadface: Username is required");
   	    assertEquals("Swag Labs",driver.getTitle());
    }
    @Test
    public void testOneInputLogin() {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("username");
    	login.clickLogin();
    	assertEquals(login.invaliddata(),"Epic sadface: Password is required");
    }
    @Test
    public void testProductPage()  {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	ProductsPage product=new ProductsPage(driver);
    	product.filterClick();
    	product.filterAtoZclick();
    	product.addtocartclick();
    	product.addtocartclick();
    	product.cartbtnClick();
    	assertEquals(product.yourcartValidate(),"Your Cart");
    	product.removeitemClick();
    	product.checkoutClick();
    	product.firstnameEnter("roshan");
    	product.secondnameEnter("shafeek");
    	product.pincodeEnter("45677");
    	product.continueClick(); 	
    	String pricevar=product.priceValidate();
    	assertEquals(pricevar.contains("7.99"),true);
    	assertEquals(product.taxValidate().contains("0.64"),true);
    	product.finishClick();
    	product.gohomeClick();
    }
    
    @Test
    
    public void testCartaddItem() {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	ProductsPage product=new ProductsPage(driver);
    	product.filterClick();
    	product.filterAtoZclick();
    	product.addtocartclick();
    	product.addtocartclick();
    	CartPage cart=new CartPage(driver);
    	assertEquals(cart.cartBadgeValidation().equals("2"),true);
    	
    }
    
    @Test
    
    public void testCartremoveItem() {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	ProductsPage product=new ProductsPage(driver);
    	product.filterClick();
    	product.filterAtoZclick();
    	product.addtocartclick();
    	product.cartbtnClick();
    	CartPage cart=new CartPage(driver);
    	cart.removeItemClick();
    	assertEquals(0,cart.listofbadges()); 	
    	
    }
    
    @Test(groups="cart")
    public void testCartResetState() throws InterruptedException {
    	LoginPage login= new LoginPage(driver);
    	login.enterUsername("standard_user");
    	login.enterPassword("secret_sauce");
    	login.clickLogin();
    	ProductsPage product=new ProductsPage(driver);
    	product.filterClick();
    	product.filterAtoZclick();
    	product.addtocartclick();
    	product.cartbtnClick();
    	CartPage cart=new CartPage(driver);
    	cart.menuClick();
    	Thread.sleep(1000);
    	cart.resetstateClick();
    	assertEquals(0,cart.listofbadges()); 
    	assertEquals(cart.listofitemsDisplayed(),0);
    	
    	
    }
    
//    @Override
//	public void onStart(ITestContext context) {
//		extentReportsListener.onStart(context);
//	}
//	@Override
//	public void onTestStart(ITestResult result) {
//		extentReportsListener.onTestStart(result);
//	}
//	@Override
//	public void onTestSuccess(ITestResult result) {
//		extentReportsListener.onTestSuccess(result);
//	}
//	@Override
//	public void onTestFailure(ITestResult result) {
//		extentReportsListener.onTestFailure(result);
//	}
//	@Override
//	public void onTestSkipped(ITestResult result) {
//		extentReportsListener.onTestSkipped(result);
//	}
//	@Override
//	public void onFinish(ITestContext context) {
//		extentReportsListener.onFinish(context);
//	}
}
