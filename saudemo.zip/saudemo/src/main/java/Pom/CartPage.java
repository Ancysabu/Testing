package Pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
   public  WebDriver driver;
   
   public CartPage(WebDriver driver) {
	   this.driver=driver;
	   PageFactory.initElements(driver, this);
   }
   
   @FindBy(xpath="//span[@class='shopping_cart_badge']")
   WebElement cartbadge;
   
   @FindBy(xpath="(//button[@class='btn btn_secondary btn_small cart_button'])[1]")
   WebElement removeitem;
   
   @FindBy(xpath="//button[@id='react-burger-menu-btn']")
   WebElement menu;
   
   @FindBy(linkText="Reset App State")
   WebElement resetstate;
   
   public String cartBadgeValidation() {
	   return cartbadge.getText();
   }
   public void removeItemClick() {
	   removeitem.click();
   }
   
   public int listofbadges() {
	   List<WebElement> list= driver.findElements(By.xpath("//span[@class='shopping_cart_badge']"));
	   return list.size();
   }
   public void menuClick() {
	   menu.click();
   }
   public void resetstateClick() {
	   resetstate.click();
   }
   
   public int listofitemsDisplayed() {
	   List<WebElement> list1=driver.findElements(By.xpath("//div[@class='cart_item_label']"));
	   return list1.size();
   }
}
