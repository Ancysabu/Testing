package Pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductsPage {
     public WebDriver driver;
     
     public ProductsPage(WebDriver driver) {
    	 this.driver=driver;
    	 PageFactory.initElements(driver, this);
     }
     
     @FindBy(xpath="//select[@class='product_sort_container']")
     WebElement filter;
     
     @FindBy(xpath="//option[@value='za']")
     WebElement filterAtoZ;
     
     @FindBy(xpath="(//button[@class='btn btn_primary btn_small btn_inventory '])[1]")
     WebElement addtocart;
     
     @FindBy(xpath="//a[@class='shopping_cart_link']")
     WebElement cartbtn;
     
     @FindBy(xpath="//span[@class='title']")
     WebElement yourcart;
     
     @FindBy(xpath="(//button[@class='btn btn_secondary btn_small cart_button'])[1]")
     WebElement removeitem;
     
     @FindBy(xpath="//button[@class='btn btn_action btn_medium checkout_button ']")
     WebElement checkout;
     
     @FindBy(xpath="(//input[@class='input_error form_input'])[1]")
     WebElement firstname;
     
     @FindBy(xpath="(//input[@class='input_error form_input'])[2]")
     WebElement secondname;
     
     @FindBy(xpath="(//input[@class='input_error form_input'])[3]")
     WebElement pincode;
     
     @FindBy(xpath="//input[@class='submit-button btn btn_primary cart_button btn_action']")
     WebElement continuebtn;
     
     @FindBy(xpath="//div[@class='summary_subtotal_label']")
     WebElement price;
     
     @FindBy(xpath="//div[@class='summary_tax_label']")
     WebElement tax;
     
     @FindBy(xpath="//button[@class='btn btn_action btn_medium cart_button']")
     WebElement finish;
     
     @FindBy(xpath="//button[@class='btn btn_primary btn_small']")
     WebElement home;
     
     public void filterClick() {
    	 filter.click();
     }
     
     public void filterAtoZclick() {
    	 filterAtoZ.click();
     }
     
     public void addtocartclick() {
    	 addtocart.click();
     }
     
     public void cartbtnClick() {
    	 cartbtn.click();
     }
     public String yourcartValidate() {
    	 return yourcart.getText();
     }
     
     public void removeitemClick() {
    	 removeitem.click();
     }
     public void checkoutClick() {
    	 checkout.click();
     }
    
     public void firstnameEnter(String fname) {
    	 firstname.sendKeys(fname);
     }
     public void secondnameEnter(String sname) {
    	 secondname.sendKeys(sname);
     }
     public void pincodeEnter(String code) {
    	 pincode.sendKeys(code);
     }
     
     public void continueClick() {
    	 continuebtn.click();
     }
     public void finishClick() {
    	 finish.click();
     }
     
     public String priceValidate() {
    	 return price.getText();
     }
     
     public String taxValidate() {
    	 return tax.getText();
     }
     
     public void gohomeClick() {
    	 home.click();
     }
}
