package utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import utilities.FileIO;

public class ExcelHandling {

 public static String[][] getExcelData(String path, String sheetName1) throws IOException{
	FileInputStream fis = new FileInputStream(new File(path));
	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	XSSFSheet sheets = workbook.getSheet(sheetName1);
	int rowCount = sheets.getPhysicalNumberOfRows();
	int colCount = sheets.getRow(0).getPhysicalNumberOfCells();
	System.out.println("Rows "+ rowCount);
	System.out.println("Column "+colCount);
	String [][] sheetarray = new String [rowCount][colCount];
	DataFormatter dt = new DataFormatter();
	for(int i=0;i<rowCount;i++) {
		for(int j=0;j<colCount;j++) {
			sheetarray[i][j]= dt.formatCellValue(sheets.getRow(i).getCell(j));
		}
	}
	return sheetarray;
}
}