package pom;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;

public class MessagePom {
       public AndroidDriver driver;
       
       
     public MessagePom(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
     
     
     @FindBy(id="com.google.android.apps.messaging:id/conversation_list_spam_popup_positive_button")
     WebElement okBtn;
     
     @FindBy(id="com.google.android.apps.messaging:id/start_chat_fab")
     WebElement startChat;
     
     @FindBy(id="com.google.android.apps.messaging:id/recipient_text_view")
     WebElement number;
     
     @FindBy(id="com.google.android.apps.messaging:id/compose_message_text")
     WebElement msg;
     
     @FindBy(id="com.google.android.apps.messaging:id/send_message_button_icon")
     WebElement msgBtn;
     
     public void clickOk() {
    	 okBtn.click();
     }
     
     public void clickStartChat() {
    	 startChat.click();
     }
     
     public void enterNumber() {
    	number.sendKeys("9645352349");
    	Actions a = new  Actions (driver);
    	a.sendKeys(Keys.ENTER).build().perform();
     }
     
     public void enterMsg() {
    	 msg.sendKeys("Hi");;
     }
     
     public void clickMsgBtn() {
    	 msgBtn.click();
     }
     
}
