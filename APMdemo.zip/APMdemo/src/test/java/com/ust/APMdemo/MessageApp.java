package com.ust.APMdemo;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import pom.MessagePom;

public class MessageApp {
	
	     public AndroidDriver driver;
	     
	     @BeforeTest
	     public void setup() throws MalformedURLException {
	    	 UiAutomator2Options options = new UiAutomator2Options();
	    	 options.setDeviceName("Ancy phone");
	    	 options.setAppPackage("com.google.android.apps.messaging");
	    	 options.setAppActivity("com.google.android.apps.messaging.ui.ConversationListActivity");
	    	 options.setPlatformName("Android");
	    	 driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"),options);
	    	 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	    	 
	     
	     }
	     
	     @Test
	 	public void test() {
	     MessagePom messagePom = new MessagePom(driver);
	     messagePom.clickOk();
	     messagePom.clickStartChat();
	     messagePom.enterNumber();
	     messagePom.enterMsg();
	     messagePom.clickMsgBtn();
	     
	    System.out.println("message app opened ");
	     
	     
	     }
	}

