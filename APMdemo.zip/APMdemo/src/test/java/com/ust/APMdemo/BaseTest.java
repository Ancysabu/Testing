package com.ust.APMdemo;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import utilities.AndroidActions;

public class BaseTest {
	public AndroidDriver driver;

	@BeforeTest
	public void setup() throws MalformedURLException {
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Ancy_phone");
		options.setApp(
				"C:\\Users\\268847\\eclipse-workspaceAPI\\APMdemo\\src\\test\\resources\\resources\\ApiDemos-debug.apk");
		options.setPlatformName("Android");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

	}

	@Test
	public void testSettingWifi() {

		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Preference\"]")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"3. Preference dependencies\"]"))
				.click();
		driver.findElement(AppiumBy.xpath(
				"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.CheckBox"))
				.click();
		driver.findElement(AppiumBy.xpath(
				"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.RelativeLayout/android.widget.TextView"))
				.click();
		driver.findElement(AppiumBy.xpath(
				"/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.widget.LinearLayout/android.widget.EditText"))
				.sendKeys("ancy");
		driver.findElement(AppiumBy.id("android:id/button1")).click();

	}
//@Test
//	public void scrolltoEndAction() {
//	driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
//		// boolean variable will be used to determine if more scrolling is possible
//		boolean canScrollmore;
//		// loop to scroll down until no more scrolling possible
//		do {
//			// scrollgestre is a command in appium that performs scroll gesture on screen
//			// The gesture starts from point (100, 100) with a width of 200 and height of
//			// 200.
//			// in downward direction
//			// 3.0 is how much you want to scroll as percentage
//			canScrollmore = (Boolean) ((JavascriptExecutor) driver).executeScript("mobile.scrollGesture", ImmutableMap
//					.of("left", 100, "top", 100, "width", 200, "height", 200, "direction", "down", "percent", 3.0));
//		} while (canScrollmore);
//	}

	@Test
	public void scrollToText() {
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
//		driver.findElement(
//				AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Spinner\"));"));
		AndroidActions.scrollToText("Spinner");
	}

	@Test
	public void scrollToEnd() {
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
		// Define the scrollable element (e.g., a list)
		String uiScrollable = "new UiScrollable(new UiSelector().scrollable(true)).scrollToEnd(10)";
		// Perform the scroll
		driver.findElement(AppiumBy.androidUIAutomator(uiScrollable));
	}

	@Test

	public void movePictures() {
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
		driver.findElement(AppiumBy.accessibilityId("Gallery")).click();
		driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"1. Photos\"]")).click();
		WebElement firstImage = driver.findElement(AppiumBy.xpath(
				"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.Gallery/android.widget.ImageView[1]"));
		((JavascriptExecutor) driver).executeScript("mobile: swipeGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) firstImage).getId(),

						"direction", "left", "percent", 0.75));
		WebElement lastImage = driver.findElement(AppiumBy.xpath(
				"/hierarchy/android.widget.FrameLayout/android.view.ViewGroup/android.widget.FrameLayout[2]/android.widget.LinearLayout/android.widget.Gallery/android.widget.ImageView[3]"));
		((JavascriptExecutor) driver).executeScript("mobile: swipeGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) lastImage).getId(),

						"direction", "right", "percent", 0.75));

	}
   @Test
   public void draganddrop() {
	   driver.findElement(AppiumBy.xpath("//android.widget.TextView[@content-desc=\"Views\"]")).click();
	   driver.findElement(AppiumBy.accessibilityId("Drag and Drop")).click();
	   WebElement source = driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1"));
	   ((JavascriptExecutor) driver).executeScript("mobile: dragGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) source).getId(),

						"endX",647,
						"endY",651));
	   
	   
   }
	
	
	
}
