package org.example;

import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;

public class SampleTest {

    @Test
    public void test1(){
        assertEquals(false,true);
    }
}
