package UST.Testing;
public class StringManipulator {

	/*
	 * Functional Requirements
	 * 
	String Reversal:
	The tool should accept a string as input and return its reversal.
	For example, inputting "hello" should return "olleh".
	
	Palindrome Check:
	The tool should check whether a given string is a palindrome 
	(reads the same backward as forward, ignoring case).
	For instance, "Madam" should be recognized as a palindrome.
	
	Vowel Counting:
	The tool must count and return the number of vowels 
	(a, e, i, o, u) in a given string, irrespective of the case.
	For example, the string "Hello World" contains 3 vowels.
	 */
	public static String reverseString(String input) {
		
		if (input==null) {
			throw new IllegalArgumentException();
		}
		StringBuilder sb=new StringBuilder(input);
		sb.reverse();
		String s=sb.toString();
        return s;
    }
	
	public static boolean isPalindrome(String input) {
		if (input==null) {
			throw new IllegalArgumentException();
		}
		StringBuilder sb= new StringBuilder(input.toLowerCase());
		sb.reverse();
		String s=sb.toString();
		if(input.toLowerCase().equals(s)) {
			return true;
		}
		return false;
    }
	 public static int countVowels(String input) {
		 int count=0;
		 if (input==null) {
				throw new IllegalArgumentException();
			}
		
		 for(int i=0;i<input.toLowerCase().length();i++) {
			 
		 if(input.charAt(i)=='a'||input.charAt(i)=='e'||input.charAt(i)=='i'||input.charAt(i)=='o'||input.charAt(i)=='u') {
			 count++;
		 }
	        
		 }
		 return count;
	 }

}
