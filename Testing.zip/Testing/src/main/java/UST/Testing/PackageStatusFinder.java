package UST.Testing;

import java.util.Scanner;

public class PackageStatusFinder {
public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);
	String s= sc.nextLine();
//	String status= new String();
	String result=solve(s);
	System.out.println(result);
	
}
public static String solve(String s) {
	if(s==null||s.isEmpty()) {
		return("No Status");
	}
	else {
	String arr[]=s.split(";");
	return(arr[(arr.length)-1]);
	}
	
}
}
