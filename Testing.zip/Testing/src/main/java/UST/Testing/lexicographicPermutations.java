package UST.Testing;

public class lexicographicPermutations {

}
