package UST.Testing;

public class ArrayUtils {
	 public static int findMax(int[] array) {
	        if (array == null || array.length == 0) {
	            throw new IllegalArgumentException("Array must not be null or empty.");
	        }
	        int max = array[0];
	        for (int value : array) {
	            if (value > max) {
	                max = value;
	            }
	        }
	        return max;
	    }

	    public static boolean isSortedAscending(int[] array) {
	        if (array == null || array.length == 0) {
	            throw new IllegalArgumentException("Array must not be null or empty.");
	        }
	        for (int i = 0; i < array.length - 1; i++) {
	            if (array[i] > array[i + 1]) {
	                return false;
	            }
	        }
	        return true;
	    }

	    public static boolean isSortedDescending(int[] array) {
	        if (array == null || array.length == 0) {
	            throw new IllegalArgumentException("Array must not be null or empty.");
	        }
	        for (int i = 0; i < array.length - 1; i++) {
	            if (array[i] < array[i + 1]) {
	                return false;
	            }
	        }
	        return true;
	    }

	    public static int[] reverseArray(int[] array) {
	        if (array == null || array.length == 0) {
	            throw new IllegalArgumentException("Array must not be null or empty.");
	        }
	        int[] reversed = new int[array.length];
	        for (int i = 0; i < array.length; i++) {
	            reversed[i] = array[array.length - 1 - i];
	        }
	        return reversed;
	    }

}
