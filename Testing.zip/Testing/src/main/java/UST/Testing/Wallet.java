package UST.Testing;

public class Wallet {
		double b=0;

		public void deposit(double d) {
			// TODO Auto-generated method stub
			if(d>0) {
				b=b+d;
			}else {
				throw new IllegalArgumentException();
			}
		}

		public void withdraw(double d) {
			// TODO Auto-generated method stub
			if(b>d && b>0) {
				b=b-d;
			}else {
				throw new IllegalArgumentException();
			}
		}

		public double getBalance() {
			// TODO Auto-generated method stub
			return b;
		}

	}


