package UST.Testing;

public class lexicographicPermutationsTest {

}
