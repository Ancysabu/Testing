package UST.Testing;
import org.junit.Test;

import UST.Testing.StringManipulator;

import static org.junit.Assert.*;


public class StringManipulatorTest {
	

	 @Test
	    public void testReverseString() {
	        assertEquals("dcba", StringManipulator.reverseString("abcd"));
	        assertEquals("54321", StringManipulator.reverseString("12345"));
	        assertEquals("", StringManipulator.reverseString(""));
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testReverseStringWithNull() {
	        StringManipulator.reverseString(null);
	    }

	    @Test
	    public void testIsPalindrome() {
	        assertTrue(StringManipulator.isPalindrome("Madam"));
	        assertFalse(StringManipulator.isPalindrome("java"));
	        assertTrue(StringManipulator.isPalindrome("racecar"));
	        assertTrue(StringManipulator.isPalindrome(""));
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testIsPalindromeWithNull() {
	        StringManipulator.isPalindrome(null);
	    }

	    @Test
	    public void testCountVowels() {
	        assertEquals(5, StringManipulator.countVowels("aeiou"));
	        assertEquals(0, StringManipulator.countVowels("bcdfg"));
	        assertEquals(3, StringManipulator.countVowels("Hello World"));
	        assertEquals(0, StringManipulator.countVowels(""));
	    }

	    @Test(expected = IllegalArgumentException.class)
	    public void testCountVowelsWithNull() {
	        StringManipulator.countVowels(null);
	    }
	}

