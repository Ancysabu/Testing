package UST.Testing;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

public class WalletTest {
    private Wallet wallet;

    @Before
    public void setUp() {
        wallet = new Wallet();
    }

    @Test
    public void testDeposit() {
        wallet.deposit(100.0);
        assertEquals(100.0, wallet.getBalance(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDepositNegativeAmount() {
        wallet.deposit(-50.0);
    }

    @Test
    public void testWithdraw() {
        wallet.deposit(200.0);
        wallet.withdraw(50.0);
        assertEquals(150.0, wallet.getBalance(), 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithdrawInsufficientFunds() {
        wallet.deposit(100.0);
        wallet.withdraw(150.0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testWithdrawNegativeAmount() {
        wallet.withdraw(-50.0);
    }

    @Test
    public void testGetBalance() {
        wallet.deposit(500.0);
        assertEquals(500.0, wallet.getBalance(), 0.001);
    }
}
