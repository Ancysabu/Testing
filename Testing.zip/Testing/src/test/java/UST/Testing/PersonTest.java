package UST.Testing;
	

import org.junit.jupiter.api.Test;

	public class PersonTest {

		
		@Test
		public void testPerson() {
			//add new persons
			// Check the list size
			//check if the list has items with specific attributes
	        // Check for existence of a person with specific age
	        // Ensure all persons have an age greater than 20

		}
	}


