package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Routes;
import endpoints.SlackTeamEndpoints;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import payload.SlackTeamModel;
@Listeners(utilities.ExtentReportsListener.class)
public class TraineeApiTest {
	@Test(priority=1)
	public void getSingleTrainee() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=SlackTeamEndpoints.getSingle(7);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);

	}
	
//	Test method for get books list
	@Test(priority=2)
	public void getAllTrainees() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=SlackTeamEndpoints.getlist();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method for post user
	@Test(priority=3)
	public void postUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackTeamModel team1=new SlackTeamModel("abcd","xyz","abc@gmail.com","ardtjfkg");
		Response response=SlackTeamEndpoints.create(team1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	
//	Test method for update user
	@Test(priority=5)
	public void putUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackTeamModel team=new SlackTeamModel("abcde","efgh","abcefg@gmail.com","asdfgrdtjfkg");
		Response response=SlackTeamEndpoints.update(8, team);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method for update a user
	@Test(priority=5)
	public void patchUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackTeamModel team=new SlackTeamModel("abcde","efrtu","abcefg@gmail.com","asdf");
		Response response=SlackTeamEndpoints.update(7, team);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
//	Test method for delete a user
	@Test(priority=6)
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		SlackTeamModel team=new SlackTeamModel(8);
		Response response=SlackTeamEndpoints.delete(team.getId());
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

//	Test method for validating json schema for get single user
	@Test(priority=7)
    public void schemaValidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	 RestAssured.given()
	 	.baseUri(Routes.baseUri)
		.basePath(Routes.getUrii)
	    .when()
	    .get()
	    .then()
	    .assertThat()
	    .body(matchesJsonSchema(new File(System.getProperty("user.dir")+"/src/test/resources/payloads/schema.json")));
	}

}
