package com.ust.OrangeHRM;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PomOrangeHRM.BuzzPage;
import PomOrangeHRM.HomePage;
import PomOrangeHRM.LoginPage;
import PomOrangeHRM.MaintenancePage;




public class OrangeHRMTest {
	   public WebDriver driver;
    @BeforeClass
    public void beforeClass() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	driver=fn.invokeBrowser();
    	//Thread.sleep(10000);
    			
    }
    
    @BeforeMethod
    public void before() {
    	ReusableFunction fn = new ReusableFunction(driver);
    	fn.openWebsite();
    	
    }
    //Test method to test valid login
    @Test
    
    public void testValidLogin(String username,String password){
    	LoginPage login= new LoginPage(driver);
//    	Thread.sleep(1000);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLoginButton();
    	assertEquals("https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index",driver.getCurrentUrl());
        assertEquals("OrangeHRM",driver.getTitle());
    }
    //Test method to test invalid login
    @Test
    public void testInvalidLogin(String username, String password) {
    	LoginPage login=new LoginPage(driver);
    	login.enterUsername(username);
    	login.enterPassword(password);
    	login.clickLoginButton();
    	assertEquals("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login",driver.getCurrentUrl());
    	assertEquals("OrangeHRM",driver.getTitle());
    }
    //Test method to test null login
    @Test
    public void testNullLogin() {
    	LoginPage login=new LoginPage(driver);
    	login.clickLoginButton();
    	assertEquals("Required",login.displayLoginUserErrormsg());
    	assertEquals("Required",login.displayLoginPasswordErrorMsg());
  	
    }
    //Test method to test if only username is entered
    @Test
    public void testOnlyUsernameEntered(String username) {
    	LoginPage login=new LoginPage(driver);
    	login.enterUsername(username);
    	assertEquals("Required",login.displayLoginUserErrormsg());
  }
    //Test method to test if only password is entered
    @Test
    public void testOnlyPasswordEntered(String password) {
    	LoginPage login=new LoginPage(driver);
    	login.enterPassword(password);
    	assertEquals("Required",login.displayLoginPasswordErrorMsg());
    	
    }
    //BUZZ PAGE
    
   @Test
  public void testBuzzPage(String username,String password) {
	 LoginPage login=new LoginPage(driver);
	 login.enterUsername(username);
 	 login.enterPassword(password);
 	 login.clickLoginButton();
     login.clickBuzzOption();
 	 BuzzPage buzzp=new BuzzPage(driver);
     buzzp.enterToPost();
     buzzp.clickPostBtn();
   	 assertEquals("https://opensource-demo.orangehrmlive.com/web/index.php/buzz/viewBuzz",driver.getCurrentUrl());
    }
   
//   MAINTENANCE PAGE
   @Test
   public void testValidMaintenancePage(String username,String password) {
	   LoginPage login=new LoginPage(driver);
	   login.enterUsername(username);
	   login.enterPassword(password);
	   login.clickLoginButton();
	   login.clickMaintenanceOption();
	   MaintenancePage mpage=new MaintenancePage(driver);
	   mpage.enterpwd(password);
	   mpage.clickConfirm();
	   assertEquals("https://opensource-demo.orangehrmlive.com/web/index.php/maintenance/purgeEmployee",driver.getCurrentUrl());
   }
   
   @Test
   public void testInvalidMaintenancePage(String username,String password) {
	   LoginPage login=new LoginPage(driver);
	   login.enterUsername(username);
	   login.enterPassword(password);
	   login.clickLoginButton();
	   login.clickMaintenanceOption();
	   MaintenancePage mpage=new MaintenancePage(driver);
	   mpage.clickConfirm();
	   assertEquals("Required",mpage.ValidateNoPassword());
	   
   }
   
   @Test
   public void testWrongPasswordMaintenancePage(String username,String password) {
	   LoginPage login=new LoginPage(driver);
	   login.enterUsername(username);
	   login.enterPassword(password);
	   login.clickLoginButton();
	   login.clickMaintenanceOption();
	   MaintenancePage mpage=new MaintenancePage(driver);
	   mpage.enterpwd(password);
	   mpage.clickConfirm();
	   assertEquals("Invalid credentials",mpage.ValidateIncorrectPassword());
   }
   // SEARCH
   
   @Test
   public void testSearchOption() {
	   HomePage home=new HomePage(driver);
	   home.enterSearch();
	   home.searchValue();
	   assertEquals("https://opensource-demo.orangehrmlive.com/web/index.php/admin/viewSystemUsers",driver.getCurrentUrl());
	   
   }
   
 
   
}
