package Utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class FileIO {
  public static Properties properties;
  
  
  public static Properties getProperties() {
	  properties = new Properties();
	  try {
		  FileInputStream fis = new FileInputStream("C:\\Users\\268847\\eclipse-workspace\\OrangeHRM\\src\\test\\resources\\ObjectRepository\\configuration.properties");
          properties.load(fis);
	  } catch (Exception e) {
	    e.printStackTrace();
	  }
   return properties;
}
}