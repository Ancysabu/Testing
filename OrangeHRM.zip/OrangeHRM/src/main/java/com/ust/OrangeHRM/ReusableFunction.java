package com.ust.OrangeHRM;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.FileIO;

public class ReusableFunction {
    public static WebDriver driver;
    public WebDriverWait wait;
    public static Properties properties;
    public static String browser_choice;
    
    public ReusableFunction(WebDriver driver) {
    	this.driver=driver;
    	wait= new WebDriverWait(driver,Duration.ofSeconds(10));
    	properties=FileIO.getProperties();
    }
     
    public static WebDriver invokeBrowser() {
    	browser_choice = properties.getProperty("browser");
    	try {
			if (browser_choice.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", properties.getProperty("driverPath"));
				driver = DriverSetup.invokeChromeBrowser();
			} else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return driver;
    }
    
    public void openWebsite() {
		try {
			driver.get(properties.getProperty("url"));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
    
}
