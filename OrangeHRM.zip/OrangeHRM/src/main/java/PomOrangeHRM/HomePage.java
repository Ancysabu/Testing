package PomOrangeHRM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
public WebDriver driver;
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText="Admin")
	WebElement adminPage;
	@FindBy(linkText="PIM")
	WebElement employeePage;
	@FindBy(linkText="Leave")
	WebElement leave;
	@FindBy(linkText="Apply")
	WebElement apply;
	@FindBy(linkText="Leave List")
	WebElement leaves;
	@FindBy(xpath="(//div[@class='oxd-table-cell oxd-padding-cell'][8]/div)[1]")
	WebElement leaveComment;
	@FindBy(linkText="Recruitment")
	WebElement recruitment;
	@FindBy(linkText="Vacancies")
	WebElement vacancies;
	@FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[1]")
	WebElement search;
	@FindBy(xpath="//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name']")
	WebElement searchvalue;
	public void clickAdminPage() {
		adminPage.click();
	}
	public void clickEmployeePage() {
		employeePage.click();
	}
	public void clickLeave() {
		leave.click();
	}
	public void clickApplyLeave() {
		apply.click();
	}
	public String getLeaveComment() {
		return leaveComment.getText();
	}
	public void clickLeaveList() {
		leaves.click();
	}
	public void clickRecruitment() {
		recruitment.click();
	}
	public void clickVacancies() {
		vacancies.click();
	}
	public void enterSearch() {
		search.sendKeys("Admin");
	}
	public void searchValue() {
		searchvalue.click();
	}
}
