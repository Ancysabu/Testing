package PomOrangeHRM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
	
 public WebDriver driver;
 
 public LoginPage(WebDriver driver) {
	 this.driver=driver;
	 PageFactory.initElements(driver, this);
 }
  @FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[1]")
  WebElement username;
  
  @FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
  WebElement password;
  
  @FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']")
  WebElement loginbtn;
  
  @FindBy(xpath="(//span[@class='oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message'])[1]")
  WebElement loginusermsg;
  
  @FindBy(xpath="(//span[@class='oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message'])[2]")
  WebElement loginpwdmsg;
  
  @FindBy(linkText="Buzz")
  WebElement buzz;
 
  @FindBy(linkText="Maintenance")
  WebElement maintenance;
  
  @FindBy(linkText="Time")
  WebElement time;
  
  
  public void enterUsername(String uname) {
	  username.sendKeys(uname);
  }
  public void enterPassword(String pwd) {
	  password.sendKeys(pwd);
  }
  public void clickLoginButton() {
	  loginbtn.click();
  }
  public String displayLoginUserErrormsg() {
	  return loginusermsg.getText();
  }
  public String displayLoginPasswordErrorMsg() {
	  return loginpwdmsg.getText();
  }
  public void clickBuzzOption() {
	  buzz.click();
  }
  
  public void clickMaintenanceOption() {
	  maintenance.click();
  }
  public void clickTime() {
	  time.click();
  }
}
//span[@class='oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message']