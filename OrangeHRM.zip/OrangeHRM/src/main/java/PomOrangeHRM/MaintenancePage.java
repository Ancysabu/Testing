package PomOrangeHRM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MaintenancePage {
    public WebDriver driver;
    
    public MaintenancePage(WebDriver driver) {
    	this.driver=driver;
    	PageFactory.initElements(driver, this);
    }
    @FindBy(xpath="(//input[@class='oxd-input oxd-input--active'])[2]")
    WebElement pword;
    
    @FindBy(xpath="//button[@class='oxd-button oxd-button--large oxd-button--secondary orangehrm-admin-access-button']")
    WebElement confirm;
    
    @FindBy(xpath="//span[@class='oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message']")
    WebElement nopasswordmsg;
    
    @FindBy(xpath="//p[@class='oxd-text oxd-text--p oxd-alert-content-text']")
    WebElement incorrectpwd;
    
    public void enterpwd(String pwd) {
    	pword.sendKeys(pwd);
    }
    
    public void clickConfirm() {
    	confirm.click();
    }
    public String ValidateNoPassword() {
    	return nopasswordmsg.getText();
    }
    public String ValidateIncorrectPassword() {
    	return incorrectpwd.getText();
    }
}
