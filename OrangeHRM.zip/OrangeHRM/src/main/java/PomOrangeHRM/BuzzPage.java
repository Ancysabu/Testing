package PomOrangeHRM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BuzzPage {
     public WebDriver driver;
     
     public BuzzPage(WebDriver driver) {
    	 this.driver=driver;
    	 PageFactory.initElements(driver, this);
     }
     
     @FindBy(xpath="//div[@class='oxd-buzz-post oxd-buzz-post--active']")
     WebElement topost;
     
     @FindBy(xpath="//button[@class='oxd-button oxd-button--medium oxd-button--main']")
     WebElement postbtn;
     
     @FindBy(xpath="(//p[@class='oxd-text oxd-text--p orangehrm-buzz-post-body-text'])[1]")
     WebElement checkpost;
     
     public void enterToPost() {
    	 topost.sendKeys("hii");
     }
     
     public void clickPostBtn() {
    	 postbtn.click();
     }
     
     public String validateCheckPost() {
    	return checkpost.getText();
     }
}

