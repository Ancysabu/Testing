package com.ust.MockAssessment;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;

public class ValidateResponses {
	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
	@Test
	public void verifystatuscode() {
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users?page=2";
		requestSpecification=given();
		response=requestSpecification.get();
		String resString=response.prettyPrint();
		System.out.println(resString);
		validatableresponse=response.then();
		ResponseBody resBody=response.getBody();
		System.out.println(resBody.asString());
		validatableresponse.statusCode(200);
	}
}
