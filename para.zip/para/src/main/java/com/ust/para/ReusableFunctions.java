package com.ust.para;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.FileIO;

public class ReusableFunctions {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Properties properties;
	public static String browser_choice;
	
	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		properties = FileIO.getProperties();
	}
	
	public WebDriver invokeBrowser() {
		browser_choice = properties.getProperty("browser");
		try {
			if(browser_choice.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", properties.getProperty("driverPath"));
				driver = DriverSetup.invokeChromeBrowser();
			}else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return driver;
	}
	
	public void openWebsite(String url) {
		try {
			driver.get(properties.getProperty(url));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
//	/************** Switch to new tab ****************/
//	public static void switchToNewTab() {
//		try {
//			ArrayList<String> tabs = new ArrayList<String>(
//					driver.getWindowHandles());
//			driver.switchTo().window(tabs.get(tabs.size() - 1));
//		} catch (Exception e) {
//			e.printStackTrace();
//			reportFail(e.getMessage());
//		}
//	}
//	/************** Switch to prev tab ****************/
//	public static void switchToPrevTab() {
//		try {
//			ArrayList<String> tabs = new ArrayList<String>(
//					driver.getWindowHandles());
//			driver.close();
//			driver.switchTo().window(tabs.get(tabs.size() - 2));
//		} catch (Exception e) {
//			e.printStackTrace();
//			reportFail(e.getMessage());
//		}
//	}
}
