package pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/**pom class for product page**/
public class ProductPage {
public WebDriver driver;
	
	public ProductPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="(//h3[@class='card__heading h5'])[1]")
	WebElement product;
	
	@FindBy(xpath="//button[@id='ProductSubmitButton-template--15246175699062__main']")
	WebElement addtocart;
	
	@FindBy(xpath="//button[@class='drawer__close']")
	WebElement delete;
	
	@FindBy(xpath="(//span[@class='visually-hidden'])[11]")
	WebElement cartbubble;
	
	public void clickProduct() {
	  product.click();
	}
	
	public void clickAddtocart() throws InterruptedException {
		addtocart.click();
		Thread.sleep(1000);
	}
	
	public void clickDeleteIcon() throws InterruptedException {
		Thread.sleep(1000);
		delete.click();
	}
	
	public String validateCartBubble() {
		return cartbubble.getText();
	}
}

