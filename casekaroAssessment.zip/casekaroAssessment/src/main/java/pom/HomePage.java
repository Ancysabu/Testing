package pom;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**pom class for home page**/
public class HomePage {
public WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//summary[@class='header__icon header__icon--search header__icon--summary link focus-inset modal__toggle']")
    WebElement search;
	
	@FindBy(xpath="//input[@class='search__input field__input']")
	WebElement searchInput;
	
	@FindBy(xpath="//button[@class='search__button field__button']")
	WebElement searchIcon;
	
	@FindBy(xpath="//p[@class='predictive-search__item-heading predictive-search__item-query-result h5']")
	WebElement selectphone;
	
	@FindBy(xpath="(//p[@role='status'])[3]")
	WebElement validate;
	
	public void clickSearch() {
		search.click();
	}
	
	public void enterSearchInput(String input) {
		searchInput.sendKeys(input);
	}
	
	public void selectPhones() throws InterruptedException {
		Thread.sleep(1000);
		selectphone.click();
	}
	
	public String validateSearch() {
		return validate.getText();
	}
}