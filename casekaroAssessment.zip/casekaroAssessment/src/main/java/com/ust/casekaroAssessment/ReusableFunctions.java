package com.ust.casekaroAssessment;

import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.FileIO;

public class ReusableFunctions {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Properties properties;
	public static String browser_choice;
	
	public ReusableFunctions(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		properties = FileIO.getProperties();
	}
	/** method to invoke browser**/
	public WebDriver invokeBrowser() {
		browser_choice = properties.getProperty("browser");
		try {
			if(browser_choice.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", properties.getProperty("driverPath"));
				driver = DriverSetup.invokeChromeBrowser();
			}else if (browser_choice.equalsIgnoreCase("edge")) {
				driver = DriverSetup.invokeEdgeBrowser();
			}else {
				throw new Exception("Invalid browser name provided in property file");
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return driver;
	}
	/** method to open website**/
	public void openWebsite(String url) {
		try {
			driver.get(properties.getProperty(url));
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
