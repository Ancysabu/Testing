package casekaroTests;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.annotations.Listeners;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pom.HomePage;


@Listeners(utilities.ExtentReportsListener.class)
public class SearchTest implements ITestListener{
	private final WebDriver driver = Hooks.driver;
	
	@Given("User already open the website casekaro")
	public void user_already_open_the_website_casekaro() {
		 assertEquals("https://casekaro.com/",driver.getCurrentUrl());
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}
	@When("User clicks on search icon")
	public void user_clicks_on_search_icon() {
		HomePage home = new HomePage(driver);
		home.clickSearch();

	}

	@When("User input {string}")
	public void user_input(String string) {
		HomePage home = new HomePage(driver);
		home.enterSearchInput(string);

	}

	@When("User clicks on first item")
	public void user_clicks_on_first_item() throws InterruptedException {
		HomePage home = new HomePage(driver);
		home.selectPhones();

	}


	@Then("User views items")
	public void user_views_items() {
		HomePage home = new HomePage(driver);
	    assertEquals(home.validateSearch().contains("phone"),true);
	}


}
