package casekaroTests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.casekaroAssessment.ReusableFunctions;

import pom.HomePage;
import pom.ProductPage;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class CartTest {
	public WebDriver driver;
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();

	@BeforeClass(groups = "cart")
//		method for browser setup
	public void browserSetup() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		driver = rf.invokeBrowser();
	}

	@BeforeMethod(groups = "cart")
//		method to open website url
	public void before() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
	}

	@DataProvider(name = "data")
//		method to get data from excel 
	public String[][] getData() throws IOException {
		String path = System.getProperty("user.dir") + "\\TestData\\testdata.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path, sheetName);
	}

//Test method to add to cart
	@Test(dataProvider = "data", groups = "cart")

	public void test(String input) throws InterruptedException {
		HomePage home = new HomePage(driver);
		home.clickSearch();
		home.enterSearchInput(input);
		home.selectPhones();
		ProductPage product = new ProductPage(driver);
		product.clickProduct();
		product.clickAddtocart();
		product.clickDeleteIcon();
		assertEquals("1 item", product.validateCartBubble());

	}

	@AfterMethod(groups = "cart")
	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("ss/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
