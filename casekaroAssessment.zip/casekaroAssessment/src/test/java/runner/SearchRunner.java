package runner;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import utilities.ExtentReportsListener;

@CucumberOptions(

		glue="casekaroTests",
		features="C:\\Users\\268847\\eclipse-workspace\\casekaroAssessment\\src\\test\\resources\\features\\search.feature"
		)
@Listeners(utilities.ExtentReportsListener.class)
public class SearchRunner extends AbstractTestNGCucumberTests  implements ITestListener{

}
