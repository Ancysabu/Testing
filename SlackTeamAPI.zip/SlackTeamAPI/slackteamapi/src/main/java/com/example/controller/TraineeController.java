package com.example.controller;


import com.example.exception.ResourceNotFoundException;
import com.example.model.Trainee;
import com.example.repository.TraineeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trainee")
public class TraineeController {

    @Autowired
    private TraineeRepository traineeRepository;

    /**
     * Get all the trainees list
     * @return list of trainees
     */
    @GetMapping("/all")
    public List<Trainee> getAll() {
        return traineeRepository.findAll();
    }
    /**
     * Get Trainees by id
     * @param traineeid
     * @return trainee by id
     *
     */
    @GetMapping("/{id}")
    public Trainee getTraineeById(@PathVariable(value = "id" ) long traineeid) throws ResourceNotFoundException {
        Trainee trainee= traineeRepository.findById(traineeid)
                .orElseThrow(()
                        -> new ResourceNotFoundException("Trainee not found for this id :: " + traineeid));
        return ResponseEntity.ok().body(trainee).getBody();
    }

    /**
     * Get Trainee by first name
     * @param firstname
     * @return trainee by first name
     */

    @GetMapping("/firstname/{firstname}")
    public List<Trainee> getTraineeByFirstName(@PathVariable String firstname) {
        return traineeRepository.findByName(firstname);
    }

    /**
     * save trainee
     * @param trainee
     * @return trainee
     *
     */
    @PostMapping("/trainees")
    public Trainee saveTrainee(@RequestBody Trainee trainee) {
        return traineeRepository.save(trainee);
    }

    /**
     * update trainee
     * @param trainee
     * @return trainee
     */
    @PutMapping("/trainees/{id}")
    public ResponseEntity<Trainee> updateTrainee(@PathVariable long id,
                                                 @RequestBody Trainee traineedetails)
            throws ResourceNotFoundException {
        Trainee trainee= traineeRepository.findById(id)
                .orElseThrow(()
                        -> new ResourceNotFoundException("Trainee not found for this id :: " + id));
        trainee.setName(traineedetails.getName());
        trainee.setLastName(traineedetails.getLastName());
        trainee.setEmail(traineedetails.getEmail());
        trainee.setCity(traineedetails.getCity());
        final Trainee updatedTrainee = traineeRepository.save(trainee);
        return ResponseEntity.ok(updatedTrainee);
    }

    @DeleteMapping("/trainees/{id}")
    public ResponseEntity<?> deleteTrainee(@PathVariable long id) throws ResourceNotFoundException {
        Trainee trainee= traineeRepository.findById(id)
                .orElseThrow(()
                        -> new ResourceNotFoundException("Trainee not found for this id :: " + id));
        traineeRepository.delete(trainee);
        return ResponseEntity.ok().build();
    }
    @PatchMapping("/trainees/{id}")
    public ResponseEntity<Trainee> partiallyUpdateTrainee(@PathVariable long id,
                                                          @RequestBody Trainee partialTrainee)
            throws ResourceNotFoundException {
        Trainee trainee = traineeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Trainee not found for this id :: " + id));

        if (partialTrainee.getName() != null) {
            trainee.setName(partialTrainee.getName());
        }
        if (partialTrainee.getLastName() != null) {
            trainee.setLastName(partialTrainee.getLastName());
        }
        if (partialTrainee.getEmail() != null) {
            trainee.setEmail(partialTrainee.getEmail());
        }
        if (partialTrainee.getCity() != null) {
            trainee.setCity(partialTrainee.getCity());
        }

        final Trainee updatedTrainee = traineeRepository.save(trainee);
        return ResponseEntity.ok(updatedTrainee);
    }
}
