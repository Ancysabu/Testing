package com.ust.APIfoundation.endpoints;

public class Routes {

	public static String  baseuri="https://freefakeapi.io";
	public static String  path_get_all_user="/api/users";
	public static String  path_get_single_user="/api/users/{id}";
	public static String  path_post="/api/posts";
	public static String  path_put="/api/posts/{id}";
	public static String  path_delete="/api/posts/{id}";	
}
