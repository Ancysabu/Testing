package com.ust.APIfoundation.payload;

public class UserModel {

    private int id;
    private String title;
    private String content;
    private String slug;
    private String picture;
    private int user;


    public UserModel(int id, String title, String content, String slug, String picture, int user) {
        this.id=id;
        this.title = title;
        this.content = content;
        this.slug = slug;
        this.picture = picture;
        this.user = user;
        
    }


    public UserModel( String title, String content, String slug, String picture, int user) {
       
        this.title = title;
        this.content = content;
        this.slug = slug;
        this.picture = picture;
        this.user = user;
        
    }
    
    public int getId() {
    	return id;
    }
    
    public void setId(int id){
    	this.id=id;
    }

	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getContent() {
		return content;
	}



	public void setContent(String content) {
		this.content = content;
	}



	public String getSlug() {
		return slug;
	}



	public void setSlug(String slug) {
		this.slug = slug;
	}



	public String getPicture() {
		return picture;
	}



	public void setPicture(String picture) {
		this.picture = picture;
	}



	public int getUser() {
		return user;
	}



	public void setUser(int user) {
		this.user = user;
	}

	 @Override
	    public String toString() {
	        return "Usermodel{" +
	                "id=" + id +
	                ", title='" + title + '\'' +
	                ", content='" + content + '\'' +
	                ", slug='" + slug + '\'' +
	                ", picture='" + picture+ '\'' +
	                
	                ", user=" + user +
	                '}';
	    }

   
}
