package com.ust.APIfoundation.endpoints;

import com.ust.APIfoundation.payload.UserModel;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;


public class UserEndPoints {
	/** method to get response of GET all users**/
	public static Response getAllUsers() {
  	  Response response = RestAssured.given()
                .baseUri(Routes.baseuri)
                .basePath(Routes.path_get_all_user)
                .contentType("application/json")
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
  }

	/** method to get response of GET single user**/
	public static Response getSingleUsers(Integer id) {
  	  Response response = RestAssured.given()
                .baseUri(Routes.baseuri)
                .basePath(Routes.path_get_single_user)
                .pathParam("id", id)
                .contentType("application/json")
                .accept(ContentType.JSON)
                .when()
                .get();
        return response;
	}
	
  /** method to get response of create user using POST **/
  public static Response createNewUserByPost(UserModel payload) {
      Response response = RestAssured.given()
              .baseUri(Routes.baseuri)
              .basePath(Routes.path_post)
              .contentType("application/json")
              .accept(ContentType.JSON)
              .body(payload)				//passing payload as body
              .when()
              .post();
      return response;
  }

  /** method to get response of updating user using PUT**/
  public static Response updateUser(UserModel payload,Integer id) {
      Response response = RestAssured.given()
              .baseUri(Routes.baseuri)
              .basePath(Routes.path_put)
              .pathParam("id", id)		//passing id as path parameter
              .contentType("application/json")
              .accept(ContentType.JSON)
              .body(payload)				//passing payload as body
              .when()
              .put();
      return response;
  }

  /** method to get response of deleting a user**/
  public static Response deleteUser(Integer id) {
      Response response = RestAssured.given()
              .baseUri(Routes.baseuri)
              .basePath(Routes.path_delete) 
              .pathParam("id", id)			//passing id as path parameter
              .contentType("application/json")
              .accept(ContentType.JSON)
              .when()
              .delete();
      return response;
  }
}


