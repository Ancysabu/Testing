package com.ust.APIfoundationrestassuredTests;

import static org.testng.Assert.assertEquals;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.APIfoundation.endpoints.UserEndPoints;
import com.ust.APIfoundation.payload.UserModel;

import io.restassured.RestAssured;
import io.restassured.response.Response;


@Listeners(com.ust.APIfoundation.utilities.ExtentReportsListener.class)
public class UserTest {

    public UserModel userPayload;

    @BeforeClass
    public void setup() {
    	//initializing payload object
    	 userPayload = new UserModel("title","title content","title slug","https://path.to/picture.jpg",1);
    			
    }
    //test method to get single user
    @Test(priority = 1)
    public void testGetSingleUser() {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = UserEndPoints.getSingleUsers(1);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
        assertEquals(response.getStatusLine(),"HTTP/1.1 200 OK");
    }
  //test method to get all users
    @Test(priority = 2)
    public void testGetAllUsers() {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = UserEndPoints.getAllUsers();
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
        assertEquals(response.getStatusLine(),"HTTP/1.1 200 OK");
    }
  //test method to create user
    
    @Test(priority = 3)
    public void testCreateUser() {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = UserEndPoints.createNewUserByPost(this.userPayload);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 201);
        assertEquals(response.getStatusLine(),"HTTP/1.1 201 Created");
    }
    
  //test method to update a user
    @Test(priority = 4)
    public void testUpdateUser() {
        RestAssured.useRelaxedHTTPSValidation();
        UserModel payloadModel =new UserModel(3,"title","title content","titllug","https://path.to/picture.jpg",1);
        Response response = UserEndPoints.updateUser(payloadModel,3);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 200);
        assertEquals(response.getStatusLine(),"HTTP/1.1 200 OK");
    }
  //test method to delete user
    @Test(priority = 5)
    public void testDeleteUser() {
        RestAssured.useRelaxedHTTPSValidation();
        Response response = UserEndPoints.deleteUser(8);
        response.then().log().all();
        assertEquals(response.getStatusCode(), 204);
        assertEquals(response.getStatusLine(),"HTTP/1.1 204 No Content");
    }
}
