package com.ust.APIfoundationrestassuredTests;

import java.io.File;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.APIfoundation.endpoints.UserEndPoints;


import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;


@Listeners(com.ust.APIfoundation.utilities.ExtentReportsListener.class)
public class SchemaValidationTest {

	//test method for schema validation
	@Test
	public void schemaValidation() {
		String schemaFilePath = System.getProperty("user.dir") + "/schema.json";
		RestAssured.useRelaxedHTTPSValidation();
		Response response = UserEndPoints.getSingleUsers(1);
        response.then().log().all().assertThat()
		.body(JsonSchemaValidator.matchesJsonSchema(new File(schemaFilePath)));
	}
}
