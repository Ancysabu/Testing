package com.ust.APIfoundationkarateTests;

import com.intuit.karate.junit5.Karate;

public class JUnitRunner {

	@Karate.Test
	Karate karateTest() {
		return Karate.run("classpath:com/ust/APIfoundationkarateTests/KarateTest.feature").relativeTo(getClass());
	}

}
