$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"4e0f9605-7d04-4992-bb89-c90c4a90e26b","feature":"invalid search","scenario":"Searching with invalid message","start":1718350683088,"group":1,"content":"","tags":"@invalidsearch,@invalidsearch,","end":1718350701432,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});