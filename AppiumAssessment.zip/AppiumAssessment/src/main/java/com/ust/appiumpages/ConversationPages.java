package com.ust.appiumpages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.ust.appiumbase.ReusableFunctions;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
//pom for conversation page
public class ConversationPages {
	public AndroidDriver driver;

	public ConversationPages(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "com.google.android.apps.messaging:id/compose_message_text")
	WebElement message;

	@AndroidFindBy(accessibility = "Send SMS")
	WebElement smsBtn;

	@AndroidFindBy(accessibility = "Navigate up")
	WebElement backBtn;

	@AndroidFindBy(accessibility = "More conversation options")
	WebElement moreOptions;

	@AndroidFindBy(className = "android.widget.TextView")
	List<WebElement> options;

	@AndroidFindBy(id = "android:id/button1")
	WebElement delete;

	public void enterMessage(String msg) {
		message.sendKeys(msg);

	}

	public void clickSmsBtn() {
		ReusableFunctions.waits(1);
		smsBtn.click();
	}

	public void clickBackBtn() {
		backBtn.click();
	}

	public void clickMoreOptions() {
		moreOptions.click();
	}

	public void selectDeleteOption() {
		ReusableFunctions.waits(1);
		options.get(4).click();

	}

	public void clickDelete() {
		delete.click();
	}

}
