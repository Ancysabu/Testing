package com.ust.appiumutils;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import org.testng.annotations.DataProvider;

import com.ust.appiumbase.ReusableFunctions;

public class DataProviders {

	@DataProvider(name="Jsondata")
	public Object[] getData() throws IOException {
		List<HashMap<String,String>> list  = ReusableFunctions.getJsonData(System.getProperty("user.dir") + "\\src\\main\\resources\\Testdata\\Data.json");
		return list.toArray();
	}
}
