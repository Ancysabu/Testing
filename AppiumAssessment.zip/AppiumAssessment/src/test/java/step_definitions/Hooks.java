package step_definitions;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Base64;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.ust.appiumutils.FileIO;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks implements ITestListener {
    public static AndroidDriver driver;
    private ExtentReports extent;
    private ExtentTest test;
    
    @Before
	public void setup() throws MalformedURLException {
    	Properties properties = FileIO.getProperties();
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName(properties.getProperty("device"));
		options.setAppPackage(properties.getProperty("appPackage"));
    	options.setAppActivity(properties.getProperty("appActivity"));
		options.setPlatformName(properties.getProperty("platformName"));
		options.setPlatformName(properties.getProperty("platformName"));
		driver = new AndroidDriver(new URL(properties.getProperty("appiumServer")), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("App opened");
		   // Initialize the Extent reports with the HTML reporter
        ExtentSparkReporter reporter = new ExtentSparkReporter("extent.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
 
        // Create a new test
        test = extent.createTest("message");
		
		
	}
 
    @After
    public void closeBrowser(){
    	//taking the screenshot after every test
   		File screenshotfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
 		try {
   			Date d1 = new Date();
 			FileUtils.copyFile(screenshotfile, new File("screenshots/"+ d1.getTime()+ "ss.jpg"));
    	} catch (IOException e) {
    		e.printStackTrace();
    	}
        //Taking the screenshot to attach in the report
        final byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        //Add it to the report
        test.addScreenCaptureFromPath("data:image/png;base64," + Base64.getEncoder().encodeToString(screenshot));
        test.pass("Test passed");
        extent.flush();
        driver.quit(); //closing the browser
    }


}