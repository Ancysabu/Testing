package step_definitions;

import static org.testng.Assert.assertEquals;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;

import com.ust.appiumpages.MessagesPages;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@Listeners(com.ust.appiumutils.ExtentReportsListener.class)
public class InvalidSearchTest implements ITestListener {
	private final AndroidDriver driver = Hooks.driver;

	@Given("User is on the message app")
	public void user_is_on_the_message_app() {
		System.out.println("App opened");
	}

	@When("User enters invalid message as {string}")
	public void user_enters_invalid_message_as(String string) {
		 MessagesPages message = new MessagesPages(driver);
		 message.clickSearchBar();
    	 message.enterSearchvalue(string);
	}

	@Then("User gets error message")
	public void user_gets_error_message() {
		 MessagesPages message = new MessagesPages(driver);
		assertEquals(message.validateSearchResult(),"No results found");
	}

}
