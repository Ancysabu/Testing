package com.ust.appiumrunner;

import org.testng.annotations.Listeners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
		glue="step_definitions",
		features="src\\test\\resources\\features\\invalidsearch.feature",
				plugin = {
						"pretty", "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:",
						"timeline:test-output-thread/" }
		)
@Listeners(com.ust.appiumutils.ExtentReportsListener.class)
public class InvalidSearchRunner extends AbstractTestNGCucumberTests {
	
}