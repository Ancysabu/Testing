package com.ust.AppiumAssessmentTests;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.appiumutils.FileIO;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;


@Listeners(com.ust.appiumutils.ExtentReportsListener.class)
public class BaseTest  implements ITestListener {
	public AndroidDriver driver;
	

	@BeforeTest
	public void setup() throws MalformedURLException {
	    Properties properties = FileIO.getProperties();
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName(properties.getProperty("device"));
		options.setAppPackage(properties.getProperty("appPackage"));
    	options.setAppActivity(properties.getProperty("appActivity"));
		options.setPlatformName(properties.getProperty("platformName"));
		options.setPlatformName(properties.getProperty("platformName"));
		driver = new AndroidDriver(new URL(properties.getProperty("appiumServer")), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		System.out.println("App opened");
	}
	
	  
    @AfterMethod

	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {

				Date d1 = new Date();

				FileUtils.copyFile(screenshot, new File("screenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
	
}
    }
}
