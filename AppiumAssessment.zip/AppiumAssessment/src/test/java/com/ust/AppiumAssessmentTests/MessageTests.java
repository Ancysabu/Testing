package com.ust.AppiumAssessmentTests;

import static org.testng.Assert.assertEquals;

import java.util.HashMap;

import org.testng.annotations.Test;

import com.ust.appiumpages.ConversationPages;
import com.ust.appiumpages.MessagesPages;
import com.ust.appiumutils.DataProviders;

public class MessageTests extends BaseTest {
//test for start conversation
	@Test(priority = 1, dataProviderClass = DataProviders.class, dataProvider = "Jsondata")
	public void startConversation(HashMap<String, String> map) {
		MessagesPages message = new MessagesPages(driver);
		message.clickOk();
		message.clickStartChat();
		message.enterNumber(map.get("number"));
		ConversationPages conversation = new ConversationPages(driver);
		conversation.enterMessage(map.get("message"));
		conversation.clickSmsBtn();
		conversation.clickBackBtn();
//assertions to validate conversation details
		assertEquals(message.validateSendMessage().contains(map.get("message")), true);
		assertEquals(message.validateSendNumber().contains(map.get("number")), true);

	}
//test for delete conversation
	@Test(priority = 2, dataProviderClass = DataProviders.class, dataProvider = "Jsondata")
	public void deleteConversation(HashMap<String, String> map) {
		MessagesPages message = new MessagesPages(driver);
		message.clickConversation();
		ConversationPages conversation = new ConversationPages(driver);
		conversation.clickMoreOptions();
		conversation.selectDeleteOption();
		conversation.clickDelete();
		message.clickSearchBar();
		message.enterSearchvalue(map.get("message"));
//assertion to validate delete conversation
		assertEquals(message.validateSearchResult(), "No results found");

	}

}
