package endpoints;

import java.io.File;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.Model;


public class Endpoints {
	
//	Response method for get list
	public static Response getlogin() {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.get_login)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.when()
				.get();
		return response;	
	}
	
//	Response method for create new trainee
	public static Response create(Model payload) {
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.post)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.post();
		return response;	
	}

//	Response method for update a trainee
	public static Response update(String user, Model payload) {
		
		Response response = RestAssured.given()
				.headers(
						
						"Content-Type",
						ContentType.JSON,
						"Accept",
						ContentType.JSON)
				.baseUri(Routes.baseUri)
				.basePath(Routes.put)
				.pathParam("username", user)
				.contentType("application/json")
				.accept(ContentType.JSON)
				.body(payload)
				.when()
				.put();
		return response;	
	}
	
//	Response method for delete trainee
	public static Response delete(String user) {
		Response response = RestAssured.given()
			.headers(
					
					"Content-Type",
					ContentType.JSON,
					"Accept",
					ContentType.JSON)
			.baseUri(Routes.baseUri)
			.basePath(Routes.delete)
			.pathParam("username", user)
			.contentType("application/json")
			.accept(ContentType.JSON)
			.when()
			.delete();
		return response;	
	}
	

}
