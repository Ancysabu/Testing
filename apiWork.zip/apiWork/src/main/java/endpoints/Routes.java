package endpoints;

public class Routes {
	public static String baseUri="https://petstore.swagger.io/";
	public static String get_login="v2/user/login?username=user&password=password";
    public static String post="v2/user";
	public static String put="v2/user/{username}";
	public static String delete="v2/user/{username}";
	public static String getUrii="v2/6";
}
