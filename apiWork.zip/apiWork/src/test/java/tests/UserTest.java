package tests;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchema;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import endpoints.Endpoints;
import endpoints.Routes;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import payload.Model;

@Listeners(utilities.ExtentReportsListener.class)
public class UserTest {
	@Test(priority=1)
	public void getLogin() {
		RestAssured.useRelaxedHTTPSValidation();
		Response response=Endpoints.getlogin();
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);

	}
	
	
//	Test method for post user
	@Test(priority=2)
	public void postUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Model team1=new Model(1,"xyz","first","last","abc@gmail.com","abc12","8765434434",0);
		Response response=Endpoints.create(team1);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	
//	Test method for update user
	@Test(priority=3)
	public void putUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Model team=new Model(1,"xyz","first","last","ab@gmail.com","abc12","8765434434",0);
		Response response=Endpoints.update("xyz", team);
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}
	
	
//	Test method for delete a user
	@Test(priority=4)
	public void deleteUser() {
		RestAssured.useRelaxedHTTPSValidation();
		Model team=new Model(8);
		Response response=Endpoints.delete("xyz");
		response.then().log().all();
		assertEquals(response.getStatusCode(), 200);
	}

//	Test method for validating json schema for get single user
	@Test(priority=5)
    public void schemaValidation() {
	 RestAssured.useRelaxedHTTPSValidation();
	 Model team1=new Model(1,"xyz","first","last","abc@gmail.com","abc12","8765434434",0);
	 RestAssured.given()
	 	.baseUri(Routes.baseUri)
		.basePath(Routes.post)
		.body(team1)
		.accept(ContentType.JSON)
	    .when()
	    .get()
	    .then()
	    .log().all()
	    .assertThat()
	    .body(matchesJsonSchema(new File(System.getProperty("user.dir")+"/src/test/resources/payloads/schema.json")));
	}

}
