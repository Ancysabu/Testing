package com.ust.demoblaze;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pomdemoblaze.CartPage;
import pomdemoblaze.HomePage;
import utilities.ExcelHandling;




public class CartTest {
public WebDriver driver;
	
	@BeforeClass(groups="cart")
	public void browserSetup() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		driver = rf.invokeBrowser();
	}
	
	@BeforeMethod(groups="cart")
	public void before() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
	}
	@DataProvider(name="valid")
	public String[][] getData() throws IOException{
		String path = System.getProperty("user.dir")+"\\TestData\\fillup data.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path,sheetName);
	}
	@Test(dataProvider="valid" , groups="cart")
	
	public void testCart(String name, String country,String city,String creditcard,String month,String year) throws InterruptedException {
		HomePage home= new HomePage(driver);
		Thread.sleep(10000);
		home.clickProduct();
		CartPage cart= new CartPage(driver);
		Thread.sleep(10000);
		cart.clickAddToCart();
		Thread.sleep(10000);
		cart.clickCart();
		assertEquals("https://www.demoblaze.com/cart.html",driver.getCurrentUrl());
		Thread.sleep(1000);
//		cart.clickDelete();
//		Thread.sleep(1000);
//		assertEquals(cart.validateDelete(),0);
		cart.clickPlaceOrder();
		Thread.sleep(1000);
		cart.enterName(name);
		cart.enterCountry(country);
		cart.enterCity(city);
		cart.enterCreditCard(creditcard);
		cart.enterMonth(month);
		cart.enterYear(year);
		
		cart.clickPurchase();
		Thread.sleep(1000);
		cart.clickOK();
		
		
		
	}
}
