package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

public class SignUpRunner {
	@CucumberOptions(
			glue="com.ust.demoblaze",
			features="C:\\Users\\268847\\eclipse-workspace\\demoblaze\\src\\test\\resources\\features\\SignUp.feature"
			)
	public class LoginTestRunner extends AbstractTestNGCucumberTests{
	}
}
