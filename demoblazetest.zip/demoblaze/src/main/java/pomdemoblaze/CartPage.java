package pomdemoblaze;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CartPage {
public WebDriver driver;
	
	public CartPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	@FindBy(linkText="Add to cart")
	WebElement addToCart;
	
	@FindBy(linkText="Cart")
	WebElement cart;
	
	@FindBy(linkText="Delete")
	WebElement delete;
	
	@FindBy(xpath="//button[@class='btn btn-success']")
	WebElement placeOrder;
	
	@FindBy(xpath="//input[@id='name']")
	WebElement name;
	
	@FindBy(xpath="//input[@id='country']")
	WebElement country;
	
	@FindBy(xpath="//input[@id='city']")
	WebElement city;
	
	@FindBy(xpath="//input[@id='card']")
	WebElement creditcard;
	
	@FindBy(xpath="//input[@id='month']")
	WebElement month;
	
	@FindBy(xpath="//input[@id='year']")
	WebElement year;
	
	@FindBy(xpath="(//button[@class='btn btn-primary'])[3]")
	WebElement purchase;
	
	@FindBy(xpath="//button[@class='confirm btn btn-lg btn-primary']")
	WebElement ok;
	
	public void clickAddToCart() throws InterruptedException {
		addToCart.click();
		Thread.sleep(10000);
		Alert a=driver.switchTo().alert();
	    a.accept();
	}
	
	public void clickCart() {
		cart.click();
	}
	
	public void clickDelete() {
		delete.click();
	}
	
	public int validateDelete() {
		List<WebElement> list= driver.findElements(By.xpath("//table[@class='table table-bordered table-hover table-striped']/tbody/tr"));
		return list.size();
	}
	
	public void clickPlaceOrder() {
		placeOrder.click();
	}
	
	public void enterName(String nme) {
		name.sendKeys(nme);
	}
	
	public void enterCountry(String ctry) {
		country.sendKeys(ctry);
	}
	
	public void enterCity(String cty) {
		city.sendKeys(cty);
	}
	
	public void enterCreditCard(String crd) {
		creditcard.sendKeys(crd);
	}
	public void enterMonth(String mnth) {
		month.sendKeys(mnth);
	}
	public void enterYear(String yr) {
		year.sendKeys(yr);
	}
	
	public void clickPurchase() {
		purchase.click();
	}
	
	public void clickOK() {
		ok.click();
	}
}

