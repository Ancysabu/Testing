package pomdemoblaze;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
public WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(linkText="Sign up")
	WebElement signUp;
	
	@FindBy(xpath="//input[@id='sign-username']")
	WebElement username;
	
	@FindBy(xpath="//input[@id='sign-password']")
	WebElement password;
	
	@FindBy(xpath="(//button[@class='btn btn-primary'])[2]")
	WebElement signUpButton;
	
	@FindBy(linkText="Samsung galaxy s6")
	WebElement product;
	
	
	public void clickSignUp() {
		signUp.click();
	}
	
	public void enterUsername(String uname) {
		username.clear();
		username.sendKeys(uname);
	}
	
	public void enterPassword(String pword) {
		password.clear();
		password.sendKeys(pword);
	}
	
	public void clickSignUpButton() throws InterruptedException {
		signUpButton.click();
		Thread.sleep(1000);
	}
	
	public void clickProduct() {
		product.click();
	}
	
	
	
	

	
}
