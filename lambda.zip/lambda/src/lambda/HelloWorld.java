package lambda;

public class HelloWorld implements I2 {
//without using lambda expressions
public void m1(){
	System.out.println("Hello World");
}
public static void main(String[] args) {
	HelloWorld obj= new HelloWorld();
	obj.m1();
}
}
