package lambda;

public class Main {

}
