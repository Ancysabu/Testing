package lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Book{
	int bookId;
	String bookName;
	
	public Book(int bookId,String bookName) {
		this.bookId=bookId;
		this.bookName=bookName;
	}
}
public class LambdaComparator {
	public static void main(String[] args) {
//		creating list
		List<Book> list=new ArrayList<Book>();
		list.add(new Book(1,"abc"));
		list.add(new Book(2,"pqr"));
		list.add(new Book(3,"det"));
		list.add(new Book(4,"fdf"));
		
// before sorting
		System.out.println("before sorting");
	for(Book i: list) {
		System.out.println( i);
	}
//	sorting 
//	System.out.println("after sorting");
//	Collections.sort(list);
//	System.out.println(list);
}
}