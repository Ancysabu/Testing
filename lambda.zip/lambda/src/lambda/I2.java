package lambda;

public interface I2 {
	public void m1();
}
