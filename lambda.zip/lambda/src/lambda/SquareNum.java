package lambda;

public class SquareNum  {
//	with using lambda
	public static void main(String[] args) {
		I3 i3=(i)->i*i;
		System.out.println(i3.squareofNumber(5));
	}

}
