package lambda;

import java.util.ArrayList;
import java.util.List;

public class listJava8 {
	public static void main(String[] args) {
		List<String> list= new ArrayList();
		list.add("ancy");
		list.add("lakshmi");
		list.add("sree");
		list.add("aishu");
		list.add("sandra");
		list.add("remya");
		for(String i: list) {
			System.out.println(i);
		}
	}
	

}
