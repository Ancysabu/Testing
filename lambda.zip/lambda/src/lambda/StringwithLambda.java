package lambda;

interface I5{
	public void m1(String str);
}
//using lambda
public class StringwithLambda {
	public static void main(String[] args) {
		I5 i5=(str)->{
			System.out.println(str.toUpperCase());
		};
		i5.m1("hiuhygif");
	}

}
//without using lambda
class 