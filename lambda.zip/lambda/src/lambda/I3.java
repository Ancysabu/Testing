package lambda;

public interface I3 {
public int squareofNumber(int n);
	

}
