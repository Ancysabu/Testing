package com.ust.DemoBlazeAssessment;

import static org.testng.Assert.assertEquals;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pomdemoblaze.CartPage;
import pomdemoblaze.HomePage;
import utilities.ExcelHandling;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class CartTest implements ITestListener{
public WebDriver driver;
ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	
	@BeforeClass(groups="cart")
//	method for browser setup
	public void browserSetup() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		driver = rf.invokeBrowser();
	}
	
	@BeforeMethod(groups="cart")
//	method to open website url
	public void before() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
	}
	@DataProvider(name="data")
//	method to get data from excel 
	public String[][] getData() throws IOException{
		String path = System.getProperty("user.dir")+"\\TestData\\fillup data.xlsx";
		String sheetName = "fillupdata";
		return ExcelHandling.getExcelData(path,sheetName);
	}

//    test method to validate the purchase order functionality of cart page
	@Test(dataProvider="data",groups="cart")
	
	public void testCart(String Name,String Country,String City,String Creditcard,String Month,String Year) throws InterruptedException {
		HomePage homepage= new HomePage(driver);
		Thread.sleep(1000);
		homepage.clickPhones();
		homepage.clickProduct();
		Thread.sleep(1000);
		homepage.clickAddToCart();
		CartPage cartpage= new CartPage(driver);
		cartpage.clickCart();
//		assertions validating the website's url and title
		assertEquals("https://www.demoblaze.com/cart.html",driver.getCurrentUrl());
		assertEquals("STORE",driver.getTitle());
		cartpage.clickPlaceOrder();
		Thread.sleep(1000);
		cartpage.enterName(Name);
		cartpage.enterCountry(Country);
		cartpage.enterCity(City);
		cartpage.enterCreditCard(Creditcard);
		cartpage.enterMonth(Month);
		cartpage.enterYear(Year);
		Thread.sleep(1000);
		cartpage.clickPurchase();
		cartpage.clickOK();
//		assertions validating the website's url after testing cart features
		assertEquals("https://www.demoblaze.com/index.html",driver.getCurrentUrl());
	
	}
	
	@AfterMethod(groups="cart")
	public void captureScreenshotOfFail(ITestResult result) {
		if(result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {
				Date d1 = new Date();
				FileUtils.copyFile(screenshot, new File("ss/"+ d1.getTime()+ "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
