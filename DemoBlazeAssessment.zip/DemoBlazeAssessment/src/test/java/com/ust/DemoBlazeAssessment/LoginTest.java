package com.ust.DemoBlazeAssessment;

import static org.testng.Assert.assertEquals;
import java.time.Duration;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.testng.ITestListener;
import org.testng.annotations.Listeners;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pomdemoblaze.HomePage;
import utilities.ExtentReportsListener;

@Listeners(utilities.ExtentReportsListener.class)
public class LoginTest implements ITestListener{
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
	private final WebDriver driver = Hooks.driver;
	
	
	@Given("User already open the website DemoBlaze")
	public void user_already_open_the_website_demo_blaze() {
		 assertEquals("https://www.demoblaze.com/",driver.getCurrentUrl());
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	@When("User navigate to login page")
	public void user_navigate_to_login_page() {
	   HomePage homepage = new HomePage(driver);
	   homepage.clickLogin();
	}

	@When("User input {string} as Username {string} as Password")
	public void user_input_as_username_as_password(String string, String string2) {
		 HomePage homepage = new HomePage(driver);
		 homepage.enterUsername(string);
		 homepage.enterPassword(string2);
	}

	@When("User click on Login button")
	public void user_click_on_login_button() throws InterruptedException {
		HomePage homepage = new HomePage(driver);
		homepage.clickLoginButton();
	}

	@Then("User logged in successfully")
	public void user_logged_in_successfully() {
		HomePage homepage = new HomePage(driver);
		assertEquals("Welcome johnDoe",homepage.validateLogin());
	}

	@Then("User get error message as alert")
	public void user_get_error_message_as_alert() throws InterruptedException {
		Thread.sleep(100);
		Alert a=driver.switchTo().alert();
	    a.accept();
	}


}
