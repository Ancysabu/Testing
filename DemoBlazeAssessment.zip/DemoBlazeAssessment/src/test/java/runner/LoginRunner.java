package runner;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import utilities.ExtentReportsListener;

@CucumberOptions(
//     	tags="@positive",
		glue="com.ust.DemoBlazeAssessment",
		features="C:\\Users\\268847\\eclipse-workspace\\DemoBlazeAssessment\\src\\test\\resources\\features\\Login.feature"
		)
@Listeners(utilities.ExtentReportsListener.class)
public class LoginRunner extends AbstractTestNGCucumberTests  implements ITestListener{
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();
}
