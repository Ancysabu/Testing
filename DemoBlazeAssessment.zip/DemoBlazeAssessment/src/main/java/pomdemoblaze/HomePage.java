package pomdemoblaze;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/**pom class for home page**/
public class HomePage {
public WebDriver driver;
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(linkText="Log in")
	WebElement login;
	
	@FindBy(xpath="//input[@id='loginusername']")
	WebElement username;
	
	@FindBy(xpath="//input[@id='loginpassword']")
	WebElement password;
	
	@FindBy(xpath="(//button[@class='btn btn-primary'])[3]")
	WebElement loginButton;
	
	@FindBy(linkText="Welcome johnDoe")
	WebElement validate;
	
	@FindBy(linkText="Phones")
	WebElement phones;
	
	@FindBy(linkText="Samsung galaxy s6")
	WebElement product;
	
	@FindBy(linkText="Add to cart")
	WebElement addToCart;
	
	/**	method to click login option**/
	
	public void clickLogin() {
		login.click();
	}
	/**	method to enter username**/
	
	public void enterUsername(String uname) {
		username.clear();
		username.sendKeys(uname);
	}
	/**	method to enter password**/
	
	public void enterPassword(String pword) {
		password.clear();
		password.sendKeys(pword);
	}
	/**	method to click login button**/
	
	public void clickLoginButton() throws InterruptedException {
		loginButton.click();
		Thread.sleep(1000);
	}
	/**	method to validate login feature**/
	public String validateLogin() {
		return validate.getText();
	}
	/**	method to click phones option**/
	
	public void clickPhones() {
		phones.click();
	}
	/**	method to click product option**/
	
	public void clickProduct() {
		product.click();
	}
	
	/**	method to click add to cart option**/
	
	public void clickAddToCart() throws InterruptedException {
		addToCart.click();
		Thread.sleep(1000);
		Alert a=driver.switchTo().alert();
	    a.accept();
	}
	
}


