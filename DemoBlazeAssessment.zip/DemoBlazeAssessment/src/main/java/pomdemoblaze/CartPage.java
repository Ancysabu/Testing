package pomdemoblaze;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/**pom class for cart page**/
public class CartPage {
public WebDriver driver;
	
	public CartPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(linkText="Cart")
	WebElement cart;
	
	@FindBy(xpath="//button[@class='btn btn-success']")
	WebElement placeOrder;
	
	@FindBy(xpath="//input[@id='name']")
	WebElement name;
	
	@FindBy(xpath="//input[@id='country']")
	WebElement country;
	
	@FindBy(xpath="//input[@id='city']")
	WebElement city;
	
	@FindBy(xpath="//input[@id='card']")
	WebElement creditcard;
	
	@FindBy(xpath="//input[@id='month']")
	WebElement month;
	
	@FindBy(xpath="//input[@id='year']")
	WebElement year;
	
	@FindBy(xpath="(//button[@class='btn btn-primary'])[3]")
	WebElement purchase;
	
	@FindBy(xpath="//button[@class='confirm btn btn-lg btn-primary']")
	WebElement ok;
	
/**	method to click cart option**/
	public void clickCart() {
		cart.click();
	}
/**method to click place order button**/
	public void clickPlaceOrder() throws InterruptedException {
		Thread.sleep(1000);
		placeOrder.click();
	}
/**	method to enter name
 * @param =names
 **/
	public void enterName(String names) {
		name.sendKeys(names);
	}
/**	method to enter country
 *  @param =cntry
 **/
	public void enterCountry(String cntry) {
		country.sendKeys(cntry);
	}
/**	method to enter city
 *  @param =cities
**/
	public void enterCity(String cities) {
		city.sendKeys(cities);
	}
/**	method to enter credit card
 * * @param =card
 **/
	public void enterCreditCard(String card) {
		creditcard.sendKeys(card);
	}
/**	method to enter months
 * @param =months
 **/
	public void enterMonth(String months) {
		month.sendKeys(months);
	}
/**	method to enter year
  * @param =years
 **/
	public void enterYear(String years) {
		year.sendKeys(years);
	}
/**	method to click purchase button**/
	public void clickPurchase() {
		purchase.click();
	}
/**	method to click OK button**/
	public void clickOK() throws InterruptedException {
		Thread.sleep(1000);
		ok.click();
	}
}