package com.ust.pom;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class CalculatorPages {
	public AndroidDriver driver;

	public CalculatorPages(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "com.android.calculator2:id/digit_6")
	WebElement six;
	
	@AndroidFindBy(id = "com.android.calculator2:id/digit_2")
	WebElement two;

	@AndroidFindBy(accessibility  = "plus")
	WebElement plus;
	
	@AndroidFindBy(accessibility  = "minus")
	WebElement minus;
	
	@AndroidFindBy(accessibility  = "multiply")
	WebElement multiply;
	
	@AndroidFindBy(accessibility  = "divide")
	WebElement divide;
	
	@AndroidFindBy(accessibility = "equals")
	WebElement equals;
	
	@AndroidFindBy(id = "com.android.calculator2:id/result")
	WebElement result;
	
	public void clickSix() {
		six.click();
	}
	
	public void clickTwo() {
		two.click();
	}
	
	public void clickPlus() {
		plus.click();
	}
	
	public void clickMinus() {
		minus.click();
	}
	
	public void clickMultiply() {
		multiply.click();
	}
	
	public void clickDivide() {
		divide.click();
	}
	public void clickEquals() {
		equals.click();
	}
	
	public String validateResult() {
		return result.getText();
	}
}