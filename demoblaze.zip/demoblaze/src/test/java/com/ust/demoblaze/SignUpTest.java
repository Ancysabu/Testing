package com.ust.demoblaze;

import static org.testng.Assert.assertEquals;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pomdemoblaze.HomePage;



public class SignUpTest {
	
	private final WebDriver driver = Hooks.driver;
	
	@Given("User already on the website demoblaze")
	public void user_already_on_the_website_demoblaze() {
	   assertEquals("https://www.demoblaze.com/",driver.getCurrentUrl());
	   driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	}

	@When("User input {string} as username and {string} as password")
	public void user_input_as_username_and_as_password(String string, String string2) throws InterruptedException {
	   
	   HomePage signUp = new HomePage(driver);
	   signUp.clickSignUp();
	   signUp.enterUsername(string);
	   signUp.enterPassword(string2);
	   signUp.clickSignUpButton();
	   
	}

	@Then("User gets an alert message and user accepts it")
	public void user_gets_an_alert_message_and_user_accepts_it() {
		Alert a=driver.switchTo().alert();
		 a.accept();
	  }
	
	@When("User clicks on signup button")
	public void user_clicks_on_signup_button() throws InterruptedException {
	HomePage signUp = new HomePage(driver);
	signUp.clickSignUp();
	signUp.clickSignUpButton();
	}


	@Then("User stays in the homepage")
	public void user_stays_in_the_homepage() {
		assertEquals("https://www.demoblaze.com/",driver.getCurrentUrl());
	}
	
}
