package com.ust.demoblaze;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pomdemoblaze.HomePage;




public class CartTest {
public WebDriver driver;
	
	@BeforeClass(groups="cart")
	public void browserSetup() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		driver = rf.invokeBrowser();
	}
	
	@BeforeMethod(groups="cart")
	public void before() {
		ReusableFunctions rf = new ReusableFunctions(driver);
		rf.openWebsite("url");
	}
	
	@Test
	
	public void testCart() throws InterruptedException {
		HomePage home= new HomePage(driver);
		home.clickProduct();
	}
}
