package UST.RestAssuredMockAssessment;

import static io.restassured.RestAssured.given;

import java.io.File;

import org.hamcrest.Matchers;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import utilities.ExtentReportsListener;


@Listeners(utilities.ExtentReportsListener.class)
public class ValidateResponse {
	ExtentReportsListener extentReportsListener = new ExtentReportsListener();

	
	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
//	Test method for get request
	@Test
	public void getMethod() {
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200)
				.assertThat().statusLine("HTTP/1.1 200 OK");
		
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
		
	}
	
	@Test
	public void verifystatuscode() {
		String url="https://reqres.in/api/users?page=2";
		requestSpecification=given();
		response=requestSpecification.get();
		String resString=response.prettyPrint();
		System.out.println(resString);
		validatableresponse=response.then();
		ResponseBody resBody=response.getBody();
		System.out.println(resBody.asString());
		validatableresponse.statusCode(200);
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
	}
	
	@Test
	public void testcase2() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given().baseUri("https://reqres.in/api/users?page=2")
		.when().get().then().statusCode(200);
	}
	
//	Test method for post request
	@Test
	public void postRequest() {
		File payload=new File(System.getProperty("user.dir")+"/src/test/resources/payload/payload.json");
		String url="https://reqres.in/api/users";
		RestAssured.given()
				.baseUri(url)
				.contentType(ContentType.JSON)
				.body(payload)
				.when().post()
				.then().assertThat()
				.statusCode(201)
				.body("createdAt", Matchers.notNullValue())
				.body("createdAt.length()", Matchers.is(24))
				.body("createdAt", Matchers.matchesRegex("[A-Z0-9-:.]+$"));
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
	}
	
//	Test method for put request
	@Test
	public void putrequest() {
		String jsonString="{\"name\":\"morpheus\",\"job\":\"zion resident\"}";
		String url="https://reqres.in/api/users/2";
		RestAssured.given()
		.baseUri(url)
		.contentType(ContentType.JSON)
		.body(jsonString)
		.when().put()
		.then().assertThat()
		.statusCode(200)
		.body("updatedAt", Matchers.notNullValue())
		.body("updatedAt.length()", Matchers.is(24))
		.body("updatedAt", Matchers.matchesRegex("^[A-Z0-9-:.]+$"));
		
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
	}
	
//	Test method for delete request
	@Test
	public void deleterequest() {
		String url="https://reqres.in/api/users/2";
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given()
		.baseUri(url)
		.contentType(ContentType.JSON)
		.when().delete()
		.then().assertThat()
		.statusCode(204);
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
	}

}
