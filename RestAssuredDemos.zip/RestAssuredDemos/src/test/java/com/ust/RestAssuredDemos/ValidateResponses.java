package com.ust.RestAssuredDemos;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;
import static org.hamcrest.CoreMatchers.equalTo;
 
import java.io.File;
 
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.response.ValidatableResponse;
import io.restassured.specification.RequestSpecification;
import static io.restassured.RestAssured.given;
 
public class ValidateResponses{
	RequestSpecification requestSpecification;
	Response response;
	ValidatableResponse validatableresponse;
	
	
	@Test
	public void getMethod() {
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users";
		RestAssured.baseURI=url;
		RestAssured.given()
				.queryParam("page", "2").contentType("application/json")
				.when().get()
				.then().log().all()
				.assertThat().statusCode(200)
				.assertThat().statusLine("HTTP/1.1 200 OK")
				.assertThat().header("content-type", "application/json; charset=utf-8")
							.header("Connection", "keep-alive")
				.assertThat().body("page", equalTo(2));
				
		//print the response
		Response res=RestAssured.get(url);
		System.out.println(res.asString());
		
	}
	
	@Test
	public void verifystatuscode() {
		RestAssured.useRelaxedHTTPSValidation();
		String url="https://reqres.in/api/users?page=2";
		//create a request specification
		requestSpecification=given();
		//calling the get method
		response=requestSpecification.get();
		//lets print the response body
		String resString=response.prettyPrint();
		System.out.println(resString);
		//to perform validation on response we need to get validatatble response
		validatableresponse=response.then();
		ResponseBody resBody=response.getBody();
		System.out.println(resBody.asString());
		//get status code
		validatableresponse.statusCode(200);
	}
	
	@Test
	public void testcase2() {
		RestAssured.useRelaxedHTTPSValidation();
		RestAssured.given().baseUri("https://reqres.in/api/users?page=2")
		.when().get().then().statusCode(200);
	}
	
	@Test
	public void postRequest() {
		String jsonString="{\"name\":\"roshan\",\"job\":\"tea master\"}";
		RestAssured.given()
				.baseUri("https://reqres.in/api/users")
				.contentType(ContentType.JSON)
				.body(jsonString)
				.when().post()
				.then().assertThat()
				.statusCode(201);
	}
	
	@Test
	public void postrequest2() {
		RestAssured.useRelaxedHTTPSValidation();
		File payload=new File(System.getProperty("user.dir")+"/src/test/resources/payload/payload.json");
		RestAssured.given()
			.baseUri("https://reqres.in/api/users")
			.contentType(ContentType.JSON)
			.body(payload)
			.when().post()
			.then().assertThat()
			.statusCode(201)
			.body("token", Matchers.nullValue());
//			.body("token.length()", Matchers.is(15))
//			.body("token", Matchers.matchesRegex("^[a-zA-Z0-9]"));
	}
	
	@Test
	public void putrequest() {
		RestAssured.useRelaxedHTTPSValidation();
		File payload=new File(System.getProperty("user.dir")+"/src/test/resources/payload/payload1.json");
		RestAssured.given()
		.baseUri("https://reqres.in/api/users")
		.contentType(ContentType.JSON)
		.body(payload)
	
	}
}