package com.ust.TaruniAssessmentPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.TaruniAssessmentbase.ReusableFunctions;
//pom page for wishlistpage
public class WishListPage {
	public WebDriver driver;

	// Constructor to initialize the WebDriver object
	public WishListPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//div[@class='wh-pro-meta']/h3/a")
	WebElement itemName;

	public String validateItemName() {
		ReusableFunctions.delay(2);
		return itemName.getText();
	}
}
