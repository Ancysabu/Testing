package com.ust.TaruniAssessmentPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.TaruniAssessmentbase.ReusableFunctions;
//pom page for product page
public class ProductPage {
	public WebDriver driver;

	// Constructor to initialize the WebDriver object
	public ProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "(//span[@class='wishlist-icon'])[2]")
	WebElement wishlistIcon;

	@FindBy(xpath = "//a[@class='mob-hide header__icon h-wishlist-icon wishlist-page-widget']")
	WebElement WishListOption;

	@FindBy(xpath = "//h1[@class='product-title h3']")
	WebElement itemName;

	@FindBy(xpath = "//p[@class='predictive-search__no-results text-lg']")
	WebElement errorMsg;

	public void clickWishlistIcon() {
		ReusableFunctions.delay(2);
		wishlistIcon.click();
	}

	public void ClickWishListOption() {
		WishListOption.click();
	}

	public String validateItemName() {
		ReusableFunctions.delay(2);
		return itemName.getText();
	}

	public String validateError() {
		ReusableFunctions.delay(2);
		return errorMsg.getText();
	}
}
