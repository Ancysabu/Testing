package com.ust.TaruniAssessmentPages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.ust.TaruniAssessmentbase.ReusableFunctions;
//pom page for product page
public class HomePage {
	public WebDriver driver;
 
	// Constructor to initialize the WebDriver object
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
 
	@FindBy(linkText ="Open search")
	WebElement searchIcon;
	
	@FindBy(xpath =("//input[@class='header-search__input h5 sm:h4']"))
	WebElement searchItem;
	
	@FindBy(xpath="//div[@class='product-card__figure']")
	WebElement firstItem;
	
	
	public void openSearch() {
		searchIcon.click();
	}
	
	public void enterSearchItem(String item) {
		ReusableFunctions.delay(1);
		searchItem.sendKeys(item);
	}
	
	public void selectFirstItem() {
		ReusableFunctions.delay(3);
		firstItem.click();
	}
	
	
	 
}
