package com.ust.TaruniAssessmentTestClasses;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.TaruniAssessmentPages.HomePage;
import com.ust.TaruniAssessmentPages.ProductPage;
import com.ust.TaruniAssessmentPages.WishListPage;
import com.ust.TaruniAssessmentbase.ReusableFunctions;
import com.ust.TaruniAssessmentutilities.ExcelHandling;



@Listeners(com.ust.TaruniAssessmentutilities.ExtentReportsListener.class)
public class WishListTestCases {

      public WebDriver driver;
      
      @BeforeClass(groups = "wishlist")
//		method for browser setup
  	public void browserSetup() {
  		ReusableFunctions rf = new ReusableFunctions(driver);
  		driver = rf.invokeBrowser();
  	}
      @BeforeMethod(groups = "wishlist")
//		method to open website url
  	public void before() {
  		ReusableFunctions rf = new ReusableFunctions(driver);
  		rf.openWebsite("url");
  		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
  	}
      
      @DataProvider(name = "data")
//		method to get data from excel 
	public String[][] getData() throws IOException {
		String path = System.getProperty("user.dir") + "\\TestData\\testdata.xlsx";
		String sheetName = "Sheet1";
		return ExcelHandling.getExcelData(path, sheetName);
	}
      //test method to add items to wishlist
      @Test(dataProvider = "data",groups = "wishlist")
      
      public void testAddToWishlist(String Item) {
    	  //checking the site url
    	  assertEquals(driver.getCurrentUrl(), "https://taruni.in/");
    	  HomePage homePage = new HomePage(driver) ;
    	  homePage.openSearch();
    	  homePage.enterSearchItem(Item);
    	  homePage.selectFirstItem();
    	  ProductPage productPage = new ProductPage (driver);
    	  String nameOfItem=  productPage.validateItemName();
    	  productPage.clickWishlistIcon();
    	  productPage.ClickWishListOption();
    	  WishListPage wishListPage=new WishListPage(driver);
    	  //checking the wishlist page url
    	  assertEquals(driver.getCurrentUrl(), "https://taruni.in/apps/wishlist");
    	  //checking if the selected item matches the item on the wishlist page
    	  assertEquals(nameOfItem, wishListPage.validateItemName());
      }
      
   // Method to capture a screenshot of failed test cases
  	@AfterMethod(groups = "wishlist")
  	public void captureScreenshotOfFail(ITestResult result) {
  		if (result.getStatus() == ITestResult.FAILURE) {
  			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
  			try {

  				Date d1 = new Date();

  				FileUtils.copyFile(screenshot, new File("screenshots/" + d1.getTime() + "ss.jpg"));
  			} catch (IOException e) {
  				e.printStackTrace();
  			}
  		}
  	}
}
