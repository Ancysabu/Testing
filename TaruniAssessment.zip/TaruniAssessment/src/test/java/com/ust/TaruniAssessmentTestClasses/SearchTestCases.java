package com.ust.TaruniAssessmentTestClasses;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Listeners;

import com.ust.TaruniAssessmentPages.HomePage;
import com.ust.TaruniAssessmentPages.ProductPage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


@Listeners(com.ust.TaruniAssessmentutilities.ExtentReportsListener.class)
public class SearchTestCases {
	private final WebDriver driver = Hooks.driver;
	//stepdefinitions
	@Given("User already open the website taruni")
	public void user_already_open_the_website_taruni() {
		 assertEquals(driver.getCurrentUrl(), "https://taruni.in/");
	}

	@When("User clicks on search icon")
	public void user_clicks_on_search_icon() {
		HomePage homePage = new HomePage(driver) ;
  	    homePage.openSearch();
	}

	@When("User input {string}")
	public void user_input(String string) {
		HomePage homePage = new HomePage(driver) ;
  	    homePage.enterSearchItem(string);
	}

	@When("User clicks on first item")
	public void user_clicks_on_first_item() {
		HomePage homePage = new HomePage(driver) ;
  	    homePage.selectFirstItem();
	}

	@Then("User views items")
	public void user_views_items() {
		 ProductPage productPage = new ProductPage (driver);
   	     assertEquals(productPage.validateItemName().contains("Top"), true); 
	}

	@Then("User gets error message")
	public void user_gets_error_message() {
		 ProductPage productPage = new ProductPage (driver);
		 assertEquals(productPage.validateError().contains("No results"), true);
	}



}
