$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"2dbcab31-61fb-4b10-9997-366d16b1decd","feature":"Search","scenario":"Searching with valid item","start":1717581651166,"group":1,"content":"","tags":"@search,@positive,","end":1717581672889,"className":"passed"},{"id":"7b9217ff-9281-4d7e-8064-e1849b64ec37","feature":"Search","scenario":"Searching with invalid item","start":1717581672911,"group":1,"content":"","tags":"@search,@negative,","end":1717581687182,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});