package com.ust.TaruniAssessmentTestClasses;

import org.testng.annotations.Test;

public class WishListCases {
  @Test
  public void f() {
  }
}
