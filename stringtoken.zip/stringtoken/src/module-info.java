/**
 * 
 */
/**
 * 
 */
module stringtoken {
}