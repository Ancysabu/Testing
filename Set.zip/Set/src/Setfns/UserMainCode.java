package Setfns;

import java.util.*;

public class UserMainCode {

	public static void orderElements(int integer, List<String> list) {
		// TODO Auto-generated method stub
		Set <String> set=new HashSet<>(list);
		System.out.println("set:"+set);
		List<String> list1= new ArrayList<>(set);
		System.out.println("list1"+list1);
		
				Collections.sort(list1);
				System.out.println("sortlist"+list1);
		
	}

}
