package Setfns;

import java.util.*;
public class Main {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int size= sc.nextInt();
		List<String> list= new ArrayList<>();
		for(int i=0;i<size;i++) {
			list.add(sc.next());
		}
		UserMainCode.orderElements(size,list);

		
		
	}
	
	
	
	

}
//Sorted Array
//Write a program to read a string array, remove duplicate elements and sort the array.
//Note:
//1. The check for duplicate elements must be case-sensitive. (AA and aa are NOT
//duplicates)
//2. While sorting, words starting with upper case letters takes precedence.
//Include a class UserMainCode with a static method orderElements which accepts the
//string
//array. The return type is the sorted array.
//Create a Class Main which would be used to accept the string array and integer and call the
//static method present in UserMainCode.
//Input and Output Format:
//Input consists of an integer n which is the number of elements followed by n string values.
//Output consists of the elements of string array.