package evenarraysum;

import java.util.*;

public class UserMainCode {

	public static void addUniqueEven(int num, List<Integer> list1) {
		// TODO Auto-generated method stub
		int sum=0;
		Set<Integer> set=new HashSet<>(list1);
		List<Integer> list2=new ArrayList<>(set);
		for(int i=0;i<list2.size();i++) {
			if(list2.get(i)%2==0) {
				sum=sum+list2.get(i);
			}
			
	} 
		if (sum==0) {
			System.out.println("no even numbers");
		}else
		System.out.println(sum);
}

}
