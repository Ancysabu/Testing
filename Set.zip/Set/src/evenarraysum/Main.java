package evenarraysum;
import java.util.*;
public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		List<Integer> list1=new ArrayList<>();
		for(int i=0;i<num;i++) {
			list1.add(sc.nextInt());
		}
		UserMainCode.addUniqueEven(num,list1);
		
	}
	

}
//Write a program to read an array, eliminate duplicate elements and calculate the sum of even numbers (values) present in the array.
//Include a class UserMainCode with a static method addUniqueEven which accepts a single  integer array. The return type (integer) should be the sum of the even numbers. In case there is no even number it should  return -1.
//Create a Class Main which would be used to accept Input array and call the static method present in UserMainCode.
//Input and Output Format:
//Input consists of n+1 integers. The first integer corresponds to n, the number of elements in the array. The next 'n' integers correspond to the elements in the array.
//In case there is no even integer in the input array, print no even numbers as output. Else print  the sum.
//Refer sample output for formatting specifications.
//Assume that the maximum number of elements in the array is 20