package palindromevowel;

public class UserMainCode {

	public static void checkPalindrome(String s) {
		// TODO Auto-generated method stub
		String s1="";
		for(int i=s.length()-1;i>=0;i--) {
			s1=s1+s.charAt(i);
			
		}
	System.out.println(s1);
		
		if(s1.equals(s)) {
			int count=0;
			for(int i=0;i<s1.length();i++) {
				if(s1.charAt(i)=='a'||s1.charAt(i)=='e'||s1.charAt(i)=='i'||s1.charAt(i)=='o'||s1.charAt(i)=='u') {
					count=count+1;
				}
			}
						
			if(count>=2) {
				System.out.println("valid");
				
					
			}else
				System.out.println("invalid");
		}
		else 
			System.out.println("invalid");
	}

}