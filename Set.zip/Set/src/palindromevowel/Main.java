package palindromevowel;

import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		String s=sc.nextLine();
		UserMainCode.checkPalindrome(s);
	}

}
//Write a program to check if a given string is palindrome and contains at least two different
//vowels.
//Include a class UserMainCode with a static method checkPalindrome which accepts a string.
//The return type (integer)
//should be 1 if the above condition is satisfied, otherwise return -1.
//Create a Class Main which would be used to accept Input string and call the static method
//present in UserMainCode.
//Note – Case Insensitive while considering vowel, i.e a & A are same vowel, But Case
//sensitive while considering
//palindrome i.e abc CbA are not palindromes.
//Input and Output Format:
//Input consists of a string with maximum size of 100 characters.
//Output consists of a single Integer.