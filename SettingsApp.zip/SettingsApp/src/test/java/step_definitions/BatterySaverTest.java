package step_definitions;

import static org.testng.Assert.assertEquals;

import org.testng.ITestListener;
import org.testng.annotations.Listeners;

import com.ust.settingspom.SettingsPages;

import io.appium.java_client.android.AndroidDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

@Listeners(com.ust.appiumUtilities.ExtentReportsListener.class)
public class BatterySaverTest implements ITestListener {
	private final AndroidDriver driver = Hooks.driver;

	@Given("User is on the settings app")
	public void user_is_on_the_settings_app() {
		System.out.println("Settings App Opened");
	}

	@Given("User clicks on Battery settings")
	public void user_clicks_on_battery_settings() {
		SettingsPages settingsPages = new SettingsPages(driver);
		settingsPages.clickBatterySettings();
	}

	@When("User selects Battery Saver option")
	public void user_selects_battery_saver_option() {
		SettingsPages settingsPages = new SettingsPages(driver);
		settingsPages.clickBatterySaverOptions();
	}

	@When("User clicks on Battery Saver button")
	public void user_clicks_on_battery_saver_button() {
		SettingsPages settingsPages = new SettingsPages(driver);
		settingsPages.clickBatterySaverBtn();
		settingsPages.clickbackbtn();
	}

	@Then("battery saver is turned on")
	public void battery_saver_is_turned_on() {
		SettingsPages settingsPages = new SettingsPages(driver);
		assertEquals(settingsPages.validateBatterySaver(), "On");
	}

	@Then("battery saver is turned off")
	public void battery_saver_is_turned_off() {
		SettingsPages settingsPages = new SettingsPages(driver);
		assertEquals(settingsPages.validateBatterySaver(), "Off");
	}

}
