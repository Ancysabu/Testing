package com.ust.SettingsApp;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.ust.appiumUtilities.AppiumServerManager;
import com.ust.settingspom.SettingsPages;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;

@Listeners(com.ust.appiumUtilities.ExtentReportsListener.class)
public class SettingsTest {
	public AndroidDriver driver;

	@BeforeMethod
	public void setup() throws MalformedURLException {
		String port = AppiumServerManager.startServer();
		UiAutomator2Options options = new UiAutomator2Options();
		options.setDeviceName("Ancy_phone");
		options.setAppPackage("com.android.settings");
		options.setAppActivity("com.android.settings.Settings");
		options.setPlatformName("Android");
		driver = new AndroidDriver(new URL("http://127.0.0.1:" + port), options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Test(priority = 1)
	public void testAirplaneModeOn() {
		SettingsPages settingsPages = new SettingsPages(driver);
		settingsPages.selectItem();
		settingsPages.clickEnabledBtn();
		assertEquals(settingsPages.validateAirplaneMode(), "Airplane mode is on");
	}

	@Test(priority = 2)
	public void testAirplaneModeOff() {
		SettingsPages settingsPages = new SettingsPages(driver);
		settingsPages.selectItem();
		settingsPages.clickEnabledBtn();
		assertEquals(settingsPages.validateAirplaneMode(), "Networks available");
	}

	@AfterMethod

	public void captureScreenshotOfFail(ITestResult result) {
		if (result.getStatus() == ITestResult.FAILURE) {
			File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			try {

				Date d1 = new Date();

				FileUtils.copyFile(screenshot, new File("screenshots/" + d1.getTime() + "ss.jpg"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		AppiumServerManager.stopServer();
	}

}
