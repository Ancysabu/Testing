package com.ust.settingspom;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class SettingsPages {
public AndroidDriver driver;
	
	public SettingsPages(AndroidDriver driver) {
		this.driver = driver;
		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}
	
	@AndroidFindBy(className = "android.widget.TextView")
	List<WebElement> items;
	
	@AndroidFindBy(id="android:id/switch_widget")
	WebElement enableAirplanemode;
	
	@AndroidFindBy(className = "android.widget.TextView")
	List<WebElement> networkitems;
	
	@AndroidFindBy(className = "android.widget.RelativeLayout")
	List<WebElement> batterySaver;
	
	@AndroidFindBy(id  = "com.android.settings:id/switch_text")
	WebElement BatterySaverOn;

	
	@AndroidFindBy(id="Navigate up")
	WebElement backbtn;
	
	public void selectItem() {
		items.get(3).click();
	}
	
	public void clickEnabledBtn() {
		enableAirplanemode.click();
	}
	
	public String validateAirplaneMode() {
		return networkitems.get(1).getText();
	}
	
	public void clickBatterySettings() {
		items.get(11).click();
	}
	
	public void clickBatterySaverOptions() {	
		batterySaver.get(1).click();
	}
	
	public void clickBatterySaverBtn() {
		BatterySaverOn.click();	}
	
	public void clickbackbtn() {
		backbtn.click();
	}
	
	public String validateBatterySaver() {
		 return items.get(7).getText();
	}
}
